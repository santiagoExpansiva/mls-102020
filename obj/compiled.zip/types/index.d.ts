declare module "_102020_build.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_build" {
    export const DISTFOLDER = "wwwroot";
    export function buildModule(project: number, moduleName: string): Promise<boolean>;
}
declare module "_102020_collabAuraLiveView.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_collabAuraLiveView" {
    import { CollabLitElement } from './_100554_collabLitElement';
    import './_100554_collabNav4Menu';
    interface ITab {
        moduleName: string;
        modulePath: string;
        project: number;
        pageInitial: string;
        actualPage: string;
        icon: string | undefined;
        target: string;
    }
    export class CollabAuraLiveView102020 extends CollabLitElement {
        private msg;
        mode: 'develpoment' | 'production';
        actualTab: number;
        tabsMenu: any;
        container?: HTMLElement;
        tabs: ITab[];
        private liveViewReady;
        get iframe(): HTMLIFrameElement | null;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        init(project: number, shortName: string, folder: string): Promise<void>;
        private setEvents;
        private onTabSelected;
        private onTabClosed;
        private checkToLoadPage;
        private setInitialTabInfos;
        private setActualTabInfos;
        private openTab;
        private closeTab;
        private addTab;
        private load;
        private toogleLoading;
        private loadPage;
        private loadInProduction;
        private loadInDevelopment;
        private APP_ID;
        private clearOldPageScripts;
        private injectHTML;
        private injectJS;
        private injectScriptRunTime;
        private injectGlobalStyle;
        private functionReplaceAnchor;
        private addStyleApp;
        private addScript;
    }
}
declare module "_102020_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102020_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_project" {
    export const modules: any[];
}
declare module "_102020_start.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_start" {
    export function start(): void;
}
