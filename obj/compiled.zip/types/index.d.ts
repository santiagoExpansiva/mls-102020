declare module "_102020_/l2/aura.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/aura" {
    export class Aura {
        private channel?;
        private mode;
        running: boolean;
        open(name?: string): this;
        listen(mode?: 'develpoment' | 'production'): this;
        send(url: string, options: any): Promise<Response>;
        close(): this;
    }
    export interface RequestMsgBase {
        type: "fetch-request";
        server: string;
        url: string;
        id: string;
        options: string;
        headers: any;
    }
    export interface ResponseMsgBase {
        type: "fetch-response";
        id: string;
        body: string;
        status: number;
        headers: any;
    }
}
declare module "_102020_/l2/build.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/build" {
    export const DISTFOLDER = "wwwroot";
    export function buildModule(project: number, moduleName: string): Promise<boolean>;
}
declare module "_102020_/l2/collabAuraLiveView.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/collabAuraLiveView" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    import '/_100554_/l2/collabNav4Menu.js';
    interface ITab {
        moduleName: string;
        modulePath: string;
        project: number;
        pageInitial: string;
        actualPage: string;
        icon: string | undefined;
        target: string;
    }
    export class CollabAuraLiveView102020 extends CollabLitElement {
        private msg;
        mode: 'develpoment' | 'production';
        actualTab: number;
        tabsMenu: any;
        lastInit: number;
        container?: HTMLElement;
        tabs: ITab[];
        private liveViewReady;
        get iframe(): HTMLIFrameElement | null;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        render(): any;
        init(project: number, shortName: string, folder: string): Promise<void>;
        private setEvents;
        private onTabSelected;
        private onTabClosed;
        private checkToLoadPage;
        private setInitialTabInfos;
        private setActualTabInfos;
        private openTab;
        private closeTab;
        private addTab;
        private load;
        private toogleLoading;
        private loadPage;
        private loadInProduction;
        private loadInDevelopment;
        private APP_ID;
        private clearOldPageScripts;
        private injectHTML;
        private injectJS;
        private injectScriptRunTime;
        private injectGlobalStyle;
        private functionReplaceAnchor;
        private addStyleApp;
        private addScript;
    }
}
declare module "_102020_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102020_/l2/enhancementAura.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/enhancementAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
}
declare module "_102020_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102020_/l2/start.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/start" {
    export function start(): void;
}
declare module "_102020_/l2/agents/agentNewPrototype.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewPrototype" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    import '/_100554_/l2/widgetQuestionsForClarification.js';
    import '/_102020_/l2/agents/agentNewPrototypeFeedback.js';
    export function createAgent(): IAgent;
    export function getPayload1(context: mls.msg.ExecutionContext): PayLoad1;
    export interface PayLoad1 {
        userPrompt: string;
        userLanguage: string;
        title: string;
        questions: Record<string, Question>;
        legends: string[];
    }
    export interface Question {
        type: "open";
        question: string;
        answer: string;
    }
}
declare module "_102020_/l2/agents/agentNewPrototype2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewPrototype2" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function getPayload2(context: mls.msg.ExecutionContext): PayLoad2;
    export interface PayLoad2 {
        userLanguage: string;
        executionRegions: string[];
        title: string;
        moduleDetails: {
            userPrompt: string;
            goal: string;
            requirements: string[];
        };
        analysisResult: {
            essentialProblems: string[];
        };
        questions: Record<string, OpenQuestion | QuestionMoSCoW>;
        legends: string[];
    }
    export interface OpenQuestion {
        type: "open";
        question: string;
        answer: string;
    }
    export interface QuestionMoSCoW {
        type: "MoSCoW";
        question: string;
        answer: "must" | "should" | "could" | "won't";
    }
}
declare module "_102020_/l2/agents/agentNewPrototype3.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewPrototype3" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function getPayload3(context: mls.msg.ExecutionContext): PayLoad3;
    export interface PayLoad3 {
        finalModuleDetails: {
            userLanguage: string;
            executionRegions: string;
            userPrompt: string;
            moduleGoal: string;
            moduleName: string;
            requirements: string[];
            userRequestsEnhancements: UserRequestsEnhancements[];
        };
        pages: PageDefinition[];
        plugins: PluginDefinition[];
        pagesWireframe: PagesWireframe[];
        organism: Organism[];
    }
    export interface UserRequestsEnhancements {
        description: string;
        priority: "could" | "should";
    }
    export interface PageDefinition {
        pageSequential: number;
        pageName: string;
        pageGoal: string;
        pageRequirements: string[];
    }
    export interface PluginDefinition {
        pluginSequential: number;
        pluginName: string;
        pluginType: "ui" | "third-party";
        pluginGoal: string;
        pluginRequirements: string[];
    }
    export interface PagesWireframe {
        pageSequential: number;
        pageName: string;
        pageHtml: string[];
    }
    export interface Organism {
        organismSequential: number;
        organismTag: string;
        planning: {
            context: string;
            goal: string;
            userStories: UserStories[];
            userRequestsEnhancements?: Planning[];
            constraints?: string[];
        };
    }
    export interface UserStories {
        story: string;
        derivedRequirements: Planning[];
    }
    export interface Planning {
        description: string;
        comment?: string;
    }
}
declare module "_102020_/l2/agents/agentNewPrototype4.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewPrototype4" {
    import { IAgent } from '/_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function getPayload4(task: mls.msg.TaskData, stepId: number): PayLoad4;
    export interface PayLoad4 {
        pageHtml: string;
        organismToImplement: string[];
        images: Images[];
    }
    interface Images {
        key: string;
        searchText: string;
        type: 'raw' | 'full' | 'regular' | 'small' | 'thumb';
        height: number;
        width: number;
        toolTip: string;
    }
}
declare module "_102020_/l2/agents/agentNewPrototypeFeedback.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewPrototypeFeedback" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import { PayLoad4 } from '_102020_/l2/agents/agentNewPrototype4';
    export class AgentGeneratePrototypeFeedback100554 extends StateLitElement {
        private msg;
        task?: mls.msg.TaskData;
        agent1Running: boolean;
        agent1Complete: boolean;
        agent1ClarificationPending: boolean;
        agent1ClarificationComplete: boolean;
        agent2Running: boolean;
        agent2Complete: boolean;
        agent2ClarificationPending: boolean;
        agent2ClarificationComplete: boolean;
        agent3Running: boolean;
        agent3Complete: boolean;
        agent4Running: boolean;
        agent4Complete: boolean;
        agent4Pages: IPages[] | undefined;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private prepareState;
        private prepareAgentGeneratePrototype1;
        private prepareAgentGeneratePrototype2;
        private prepareAgentGeneratePrototype3;
        private prepareAgentGeneratePrototype4;
        private getAllSteps;
        private openPage;
    }
    interface IPages {
        index: number;
        pageName: string;
        status: 'pending' | 'completed' | 'running';
        organism: string[];
        result?: PayLoad4;
    }
}
declare module "_102020_/l2/agents/agentScaffoldToOrganismMock.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentScaffoldToOrganismMock" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
}
declare module "_102020_/l2/agents/agentUpdateMocks.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentUpdateMocks" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
}
declare module "_102020_/l2/agents/agentUpdateTemporaryEndpoints.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentUpdateTemporaryEndpoints" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
}
declare module "_102020_/l2/agents/agentUpdateTemporaryEndpoints2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentUpdateTemporaryEndpoints2" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
}
