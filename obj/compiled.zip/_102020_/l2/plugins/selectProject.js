/// <mls fileReference="_102020_/l2/plugins/selectProject.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { setProjectDetails } from '/_102027_/l2/libCommom.js';
import '/_102020_/l2/plugins/markdownViewer.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Project',
    desc: 'A project is a deliverable within an organization — it contains pages, components, and all generated code.',
    allTitle: 'All Projects',
    allDesc: 'Overview of all projects in this organization.',
    customTitle: 'New Project',
    customDesc: 'Create a new project within this organization.',
    needsOrg: 'Select an organization first to see the available projects.',
    loading: 'Loading README…',
    selectBtn: 'Select Project',
    actualProject: 'actual project',
    noReadme: 'No README found — click Edit and save to add one.',
    noResults: 'No projects match your search.',
    createNew: 'New Project',
    searchPlaceholder: 'Search projects…',
};
const messages = {
    en: message_en,
    pt: {
        title: 'Projeto',
        desc: 'Um projeto é uma entrega dentro de uma organização — contém páginas, componentes e todo o código gerado.',
        allTitle: 'Todos os Projetos',
        allDesc: 'Visão geral de todos os projetos desta organização.',
        customTitle: 'Novo Projeto',
        customDesc: 'Crie um novo projeto dentro desta organização.',
        needsOrg: 'Selecione uma organização primeiro para ver os projetos disponíveis.',
        loading: 'Carregando README…',
        selectBtn: 'Selecionar Projeto',
        actualProject: 'projeto atual',
        noReadme: 'Nenhum README encontrado — clique em Editar e salve para adicionar.',
        noResults: 'Nenhum projeto corresponde à sua busca.',
        createNew: 'Novo Projeto',
        searchPlaceholder: 'Buscar projetos…',
    },
    es: {
        title: 'Proyecto',
        desc: 'Un proyecto es un entregable dentro de una organización — contiene páginas, componentes y todo el código generado.',
        allTitle: 'Todos los Proyectos',
        allDesc: 'Visión general de todos los proyectos de esta organización.',
        customTitle: 'Nuevo Proyecto',
        customDesc: 'Cree un nuevo proyecto dentro de esta organización.',
        needsOrg: 'Seleccione una organización primero para ver los proyectos disponibles.',
        loading: 'Cargando README…',
        selectBtn: 'Seleccionar Proyecto',
        actualProject: 'proyecto actual',
        noReadme: 'No se encontró README — haga clic en Editar y guarde para añadir uno.',
        noResults: 'Ningún proyecto coincide con su búsqueda.',
        createNew: 'Nuevo Proyecto',
        searchPlaceholder: 'Buscar proyectos…',
    },
};
// ─── Component ───────────────────────────────────────────────────────
let PluginSelectProject = class PluginSelectProject extends StateLitElement {
    constructor() {
        super(...arguments);
        this.selectedOrg = null;
        this.value = null;
        this._readme = null;
        this._readmeLoading = false;
        this._search = '';
    }
    willUpdate(changed) {
        if (changed.has('value') || changed.has('selectedOrg')) {
            this._search = '';
            this._readme = null;
            const project = this._selectedProject;
            if (project)
                this._loadReadme(project.project);
        }
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang];
    }
    get _isAll() {
        return this.value === 0;
    }
    get _isCustom() {
        return this.selectedOrg !== null && this.value !== null && this.value > this.selectedOrg.projects.length;
    }
    get _selectedProject() {
        if (!this.selectedOrg || this.value === null || this.value <= 0 || this.value > this.selectedOrg.projects.length)
            return null;
        return this.selectedOrg.projects[this.value - 1];
    }
    createRenderRoot() { return this; }
    render() {
        if (!this.selectedOrg)
            return this._renderNeedsOrg();
        if (this._isAll)
            return this._renderAll();
        if (this._isCustom)
            return this._renderCustom();
        return this._renderSelected();
    }
    // ─── Async README load ────────────────────────────────────────────
    async _loadReadme(projectId) {
        this._readmeLoading = true;
        this.requestUpdate();
        try {
            const key = mls.stor.getKeyToFile({ project: projectId, level: 0, shortName: 'README', folder: '', extension: '.md' });
            const storFile = mls.stor.files[key];
            this._readme = storFile ? await storFile.getContent() : null;
        }
        catch {
            this._readme = null;
        }
        this._readmeLoading = false;
        this.requestUpdate();
    }
    // ─── Scenario renders ─────────────────────────────────────────────
    _renderNeedsOrg() {
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.title, this.msg.desc)}
                ${this._renderNotice(this.msg.needsOrg)}
            </div>
        `;
    }
    _renderSelected() {
        const project = this._selectedProject;
        const org = this.selectedOrg;
        const max = (org?.projects.length ?? 0) + 1;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.title, this.msg.desc, this.value ?? 0, 0, max)}
                ${project
            ? mls.actualProject === project.project
                ? html `<span class="
                            self-end text-[10px] px-2 py-0.5 rounded-full font-medium
                            bg-emerald-100 dark:bg-emerald-900/30
                            text-emerald-600 dark:text-emerald-400
                        ">${this.msg.actualProject}</span>`
                : html `<button
                            class="
                                self-end text-[10px] px-2.5 py-1 rounded
                                bg-indigo-500 dark:bg-indigo-600 text-white
                                hover:bg-indigo-600 dark:hover:bg-indigo-500
                                transition-colors whitespace-nowrap cursor-pointer
                            "
                            @click=${() => {
                    mls.setActualProject(project.project);
                    const orgIndex = mls.l5.getProjectOrgIndex(project.project);
                    mls.l5.setActualOrg(orgIndex);
                    setProjectDetails(project.project);
                    window.location.reload();
                }}
                        >${this.msg.selectBtn}</button>`
            : nothing}
                ${project ? this._renderSelectedProjectDetail(project, org) : nothing}
            </div>
        `;
    }
    _renderSelectedProjectDetail(project, org) {
        return html `
            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-2.5
            ">
                <div class="flex items-center gap-2">
                    <span class="text-[10px] text-gray-400 dark:text-gray-600 font-mono">${org.name}</span>
                    <span class="text-gray-300 dark:text-gray-700">/</span>
                    <span class="text-xs font-semibold text-gray-700 dark:text-gray-300">${project.name}</span>
                    <span class="ml-auto text-[10px] font-mono text-gray-400 dark:text-gray-600">#${project.project}</span>
                </div>
            </div>

            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-3
            ">
                ${this._readmeLoading
            ? html `<span class="text-xs text-gray-400 dark:text-gray-600 italic">${this.msg.loading}</span>`
            : html `
                        <plugins--markdown-viewer-102020
                            .text=${this._readme ?? this.msg.noReadme}
                            @md-save=${(e) => { this._readme = e.detail.value; }}
                        ></plugins--markdown-viewer-102020>
                    `}
            </div>
        `;
    }
    _renderAll() {
        const org = this.selectedOrg;
        const q = this._search.toLowerCase();
        const filtered = org.projects
            .map((p, i) => ({ p, selectValue: i + 1 }))
            .filter(({ p }) => !q || p.name.toLowerCase().includes(q) || String(p.project).includes(q));
        const max = org.projects.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.allTitle, this.msg.allDesc, 0, 0, max)}
                <button
                    class="
                        self-end text-[10px] px-2.5 py-1 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors whitespace-nowrap
                    "
                    @click=${() => this._dispatchSelect(max)}
                >+ ${this.msg.createNew}</button>

                <input
                    type="text"
                    .value=${this._search}
                    placeholder=${this.msg.searchPlaceholder}
                    class="
                        w-full text-xs px-2.5 py-1.5 rounded-md
                        border border-gray-200 dark:border-gray-700
                        bg-white dark:bg-gray-900
                        text-gray-700 dark:text-gray-300
                        placeholder-gray-400 dark:placeholder-gray-600
                        focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                    "
                    @input=${(e) => { this._search = e.target.value; }}
                />

                ${org.projects.length === 0
            ? nothing
            : filtered.length === 0
                ? html `<span class="text-[11px] text-gray-400 dark:text-gray-600 italic">${this.msg.noResults}</span>`
                : html `
                            <div class="flex flex-col gap-1.5">
                                ${filtered.map(({ p, selectValue }) => this._renderProjectCard(p, selectValue))}
                            </div>
                        `}
            </div>
        `;
    }
    _renderCustom() {
        const max = (this.selectedOrg?.projects.length ?? 0) + 1;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.customTitle, this.msg.customDesc, max, 0, max)}
            </div>
        `;
    }
    // ─── Shared helpers ───────────────────────────────────────────────
    _renderHeader(title, description) {
        return html `
            <div class="flex flex-col gap-1">
                <span class="text-lg font-semibold text-gray-700 dark:text-gray-200">${title}</span>
                <span class="text-xs text-gray-400 dark:text-gray-500 leading-relaxed">
                    ${description}
                </span>
            </div>
        `;
    }
    _renderNavHeader(title, desc, value, min, max) {
        const atMin = value <= min;
        const atMax = value >= max;
        const navBtn = (label, target, disabled) => html `
            <button
                class="px-1.5 py-1 rounded text-base font-mono leading-none transition-colors
                    ${disabled
            ? 'text-gray-300 dark:text-gray-700 cursor-default'
            : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer'}"
                ?disabled=${disabled}
                @click=${() => { if (!disabled)
            this._dispatchSelect(target); }}
            >${label}</button>
        `;
        return html `
            <div class="flex flex-col gap-1">
                <div class="flex items-center">
                    <div class="flex items-center gap-0.5">
                        ${navBtn('‹', value - 1, atMin)}
                        ${navBtn('«', min, atMin)}
                    </div>
                    <span class="flex-1 text-center text-lg font-semibold text-gray-700 dark:text-gray-200">${title}</span>
                    <div class="flex items-center gap-0.5">
                        ${navBtn('›', value + 1, atMax)}
                        ${navBtn('»', max, atMax)}
                    </div>
                </div>
                <span class="text-xs text-gray-400 dark:text-gray-500 leading-relaxed">${desc}</span>
            </div>
        `;
    }
    _renderNotice(message) {
        return html `
            <div class="
                rounded-lg border border-amber-200 dark:border-amber-800/40
                bg-amber-50 dark:bg-amber-900/10
                px-3 py-2.5
            ">
                <span class="text-[11px] text-amber-600 dark:text-amber-400 leading-relaxed">
                    ${message}
                </span>
            </div>
        `;
    }
    _renderProjectCard(project, selectValue) {
        const org = this.selectedOrg;
        const clickable = selectValue !== undefined;
        return html `
            <div
                class="
                    rounded-lg border border-gray-200 dark:border-gray-800
                    bg-gray-50 dark:bg-gray-900/50
                    px-3 py-2.5 flex items-center gap-2
                    ${clickable ? 'cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/70 transition-colors' : ''}
                "
                @click=${clickable ? () => this._dispatchSelect(selectValue) : nothing}
            >
                <span class="text-[10px] text-gray-400 dark:text-gray-600 font-mono">${org.name}</span>
                <span class="text-gray-300 dark:text-gray-700">/</span>
                <span class="text-xs font-medium text-gray-700 dark:text-gray-300">${project.name}</span>
                <span class="ml-auto text-[10px] font-mono text-gray-400 dark:text-gray-600">#${project.project}</span>
            </div>
        `;
    }
    _dispatchSelect(value) {
        this.dispatchEvent(new CustomEvent('select-project', {
            detail: { value },
            bubbles: true,
            composed: true,
        }));
    }
};
__decorate([
    property({ attribute: false })
], PluginSelectProject.prototype, "selectedOrg", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectProject.prototype, "value", void 0);
__decorate([
    state()
], PluginSelectProject.prototype, "_readme", void 0);
__decorate([
    state()
], PluginSelectProject.prototype, "_readmeLoading", void 0);
__decorate([
    state()
], PluginSelectProject.prototype, "_search", void 0);
PluginSelectProject = __decorate([
    customElement('plugins--select-project-102020')
], PluginSelectProject);
export { PluginSelectProject };
