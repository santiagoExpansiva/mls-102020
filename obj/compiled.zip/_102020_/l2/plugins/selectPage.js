/// <mls fileReference="_102020_/l2/plugins/selectPage.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import '/_102020_/l2/plugins/navHeader.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Pages',
    desc: 'A page represents a screen or route within the module.',
    allTitle: 'All Pages',
    allDesc: 'Overview of all pages in this module.',
    customTitle: 'New Page',
    customDesc: 'Create a new page in this module.',
    noPages: 'No pages found in this module.',
    noResults: 'No pages match your search.',
    createNew: 'New Page',
    searchPlaceholder: 'Search pages…',
    inDevelopment: 'In development',
};
const messages = {
    en: message_en,
    pt: {
        title: 'Páginas',
        desc: 'Uma página representa uma tela ou rota dentro do módulo.',
        allTitle: 'Todas as Páginas',
        allDesc: 'Visão geral de todas as páginas deste módulo.',
        customTitle: 'Nova Página',
        customDesc: 'Crie uma nova página neste módulo.',
        noPages: 'Nenhuma página encontrada neste módulo.',
        noResults: 'Nenhuma página corresponde à sua busca.',
        createNew: 'Nova Página',
        searchPlaceholder: 'Buscar páginas…',
        inDevelopment: 'Em desenvolvimento',
    },
    es: {
        title: 'Páginas',
        desc: 'Una página representa una pantalla o ruta dentro del módulo.',
        allTitle: 'Todas las Páginas',
        allDesc: 'Visión general de todas las páginas de este módulo.',
        customTitle: 'Nueva Página',
        customDesc: 'Cree una nueva página en este módulo.',
        noPages: 'No se encontraron páginas en este módulo.',
        noResults: 'Ninguna página coincide con su búsqueda.',
        createNew: 'Nueva Página',
        searchPlaceholder: 'Buscar páginas…',
        inDevelopment: 'En desarrollo',
    },
};
// ─── Component ───────────────────────────────────────────────────────
let PluginSelectPage = class PluginSelectPage extends StateLitElement {
    constructor() {
        super(...arguments);
        this.pages = [];
        this.value = null;
        this._search = '';
    }
    willUpdate(changed) {
        if (changed.has('value'))
            this._search = '';
    }
    get msg() {
        return messages[this.getMessageKey(messages)];
    }
    get _isAll() {
        return this.value === 0;
    }
    get _isCustom() {
        return this.value !== null && this.value > this.pages.length;
    }
    get _selectedPage() {
        if (this.value === null || this.value <= 0 || this.value > this.pages.length)
            return null;
        return this.pages[this.value - 1];
    }
    createRenderRoot() { return this; }
    render() {
        if (this._isAll)
            return this._renderAll();
        if (this._isCustom)
            return this._renderCustom();
        return this._renderSelected();
    }
    // ─── Scenario renders ─────────────────────────────────────────────
    _renderSelected() {
        const page = this._selectedPage;
        const max = this.pages.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                <plugins--nav-header-102020
                    .fixedLabel=${this.msg.title}
                    .itemName=${page?.name ?? ''}
                    .desc=${this.msg.desc}
                    .value=${this.value ?? 0}
                    .min=${0}
                    .max=${max}
                    @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                ></plugins--nav-header-102020>
                ${page ? this._renderPageDetail(page) : nothing}
            </div>
        `;
    }
    _renderPageDetail(page) {
        return html `
            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-2.5
            ">
                <div class="flex items-center gap-2">
                    <span class="text-sm font-semibold text-gray-700 dark:text-gray-300">${page.name}</span>
                    <span
                        class="ml-auto text-sm font-mono text-gray-400 dark:text-gray-600"
                        style="max-width:180px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis"
                    >${page.path}</span>
                </div>
            </div>
        `;
    }
    _renderAll() {
        const q = this._search.toLowerCase();
        const filtered = this.pages
            .map((p, i) => ({ p, selectValue: i + 1 }))
            .filter(({ p }) => !q || p.name.toLowerCase().includes(q) || p.path.toLowerCase().includes(q));
        const max = this.pages.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                <plugins--nav-header-102020
                    .fixedLabel=${this.msg.title}
                    .itemName=${this.msg.allTitle}
                    .desc=${this.msg.allDesc}
                    .value=${0}
                    .min=${0}
                    .max=${max}
                    @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                ></plugins--nav-header-102020>
                <button
                    class="
                        self-end text-sm px-2.5 py-1 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors whitespace-nowrap cursor-pointer
                    "
                    @click=${() => this._dispatchSelect(max)}
                >+ ${this.msg.createNew}</button>

                <input
                    type="text"
                    .value=${this._search}
                    placeholder=${this.msg.searchPlaceholder}
                    class="
                        w-full text-sm px-2.5 py-1.5 rounded-md
                        border border-gray-200 dark:border-gray-700
                        bg-white dark:bg-gray-900
                        text-gray-700 dark:text-gray-300
                        placeholder-gray-400 dark:placeholder-gray-600
                        focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                    "
                    @input=${(e) => { this._search = e.target.value; }}
                />

                ${this.pages.length === 0
            ? html `<span class="text-sm text-gray-400 dark:text-gray-600 italic">${this.msg.noPages}</span>`
            : filtered.length === 0
                ? html `<span class="text-sm text-gray-400 dark:text-gray-600 italic">${this.msg.noResults}</span>`
                : html `
                            <div class="flex flex-col gap-1.5">
                                ${filtered.map(({ p, selectValue }) => this._renderPageCard(p, selectValue))}
                            </div>
                        `}
            </div>
        `;
    }
    _renderCustom() {
        const max = this.pages.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                <plugins--nav-header-102020
                    .fixedLabel=${this.msg.title}
                    .itemName=${this.msg.customTitle}
                    .desc=${this.msg.customDesc}
                    .value=${max}
                    .min=${0}
                    .max=${max}
                    @nav-change=${(e) => this._dispatchSelect(e.detail.value)}
                ></plugins--nav-header-102020>
                <div class="
                    rounded-lg border border-amber-200 dark:border-amber-800/40
                    bg-amber-50 dark:bg-amber-900/10
                    px-3 py-2.5
                ">
                    <span class="text-sm text-amber-600 dark:text-amber-400">${this.msg.inDevelopment}</span>
                </div>
            </div>
        `;
    }
    // ─── Shared helpers ───────────────────────────────────────────────
    _renderPageCard(page, selectValue) {
        return html `
            <div
                class="
                    rounded-lg border border-gray-200 dark:border-gray-800
                    bg-gray-50 dark:bg-gray-900/50
                    hover:bg-gray-100 dark:hover:bg-gray-800/70
                    px-3 py-2.5 flex items-center gap-2
                    cursor-pointer transition-colors
                "
                @click=${() => this._dispatchSelect(selectValue)}
            >
                <span class="text-sm font-medium text-gray-700 dark:text-gray-300">${page.name}</span>
                <span
                    class="ml-auto text-sm font-mono text-gray-400 dark:text-gray-600"
                    style="max-width:150px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis"
                >${page.path}</span>
            </div>
        `;
    }
    _dispatchSelect(value) {
        this.dispatchEvent(new CustomEvent('select-page', {
            detail: { value },
            bubbles: true,
            composed: true,
        }));
    }
};
__decorate([
    property({ attribute: false })
], PluginSelectPage.prototype, "pages", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectPage.prototype, "value", void 0);
__decorate([
    state()
], PluginSelectPage.prototype, "_search", void 0);
PluginSelectPage = __decorate([
    customElement('plugins--select-page-102020')
], PluginSelectPage);
export { PluginSelectPage };
