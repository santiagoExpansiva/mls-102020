/// <mls fileReference="_102020_/l2/plugins/selectOrganization.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import '/_102020_/l2/plugins/markdownViewer.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Select Organization',
    desc: 'An organization groups multiple projects under the same umbrella. Select one to browse the projects available to your team.',
    allTitle: 'All Organizations',
    allDesc: 'Overview of all organizations available in the system.',
    customTitle: 'New Organization',
    customDesc: 'Create a new organization to group your projects.',
    projects: 'projects',
    noOrgs: 'No organizations found.',
    createNew: 'Create new organization',
    inDevelopment: 'In development',
};
const messages = {
    en: message_en,
    pt: {
        title: 'Selecionar Organização',
        desc: 'Uma organização agrupa vários projetos sob o mesmo guarda-chuva. Selecione uma para navegar pelos projetos disponíveis para o seu time.',
        allTitle: 'Todas as Organizações',
        allDesc: 'Visão geral de todas as organizações disponíveis no sistema.',
        customTitle: 'Nova Organização',
        customDesc: 'Crie uma nova organização para agrupar seus projetos.',
        projects: 'projetos',
        noOrgs: 'Nenhuma organização encontrada.',
        createNew: 'Criar nova organização',
        inDevelopment: 'Em desenvolvimento',
    },
    es: {
        title: 'Seleccionar Organización',
        desc: 'Una organización agrupa múltiples proyectos bajo el mismo paraguas. Seleccione una para explorar los proyectos disponibles para su equipo.',
        allTitle: 'Todas las Organizaciones',
        allDesc: 'Visión general de todas las organizaciones disponibles en el sistema.',
        customTitle: 'Nueva Organización',
        customDesc: 'Cree una nueva organización para agrupar sus proyectos.',
        projects: 'proyectos',
        noOrgs: 'No se encontraron organizaciones.',
        createNew: 'Crear nueva organización',
        inDevelopment: 'En desarrollo',
    },
};
// ─── Component ───────────────────────────────────────────────────────
let PluginSelectOrganization = class PluginSelectOrganization extends StateLitElement {
    constructor() {
        super(...arguments);
        this.orgs = [];
        this.value = null;
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang];
    }
    get _isAll() {
        return this.value === 0;
    }
    get _isCustom() {
        return this.value !== null && this.value > this.orgs.length;
    }
    get _selectedOrg() {
        if (this.value === null || this.value <= 0 || this.value > this.orgs.length)
            return null;
        return this.orgs[this.value - 1];
    }
    createRenderRoot() { return this; }
    render() {
        if (this._isAll)
            return this._renderAll();
        if (this._isCustom)
            return this._renderCustom();
        return this._renderSelected();
    }
    _renderSelected() {
        const org = this._selectedOrg;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.title, null, this.msg.desc)}
                ${org ? this._renderSelectedOrgDetail(org) : nothing}
            </div>
        `;
    }
    _renderSelectedOrgDetail(org) {
        const date = org.created_at ? new Intl.DateTimeFormat(undefined, { year: 'numeric', month: 'short' }).format(new Date(org.created_at)) : null;
        return html `
            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-3 flex flex-col gap-2
            ">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="text-xs font-semibold text-gray-700 dark:text-gray-300">${org.name}</span>
                    ${date ? html `<span class="text-[10px] text-gray-400 dark:text-gray-600 font-mono">(${date})</span>` : nothing}
                    <span class="text-gray-300 dark:text-gray-700">·</span>
                    <span class="
                        text-[10px] px-2 py-0.5 rounded-full font-medium
                        bg-indigo-100 dark:bg-indigo-900/30
                        text-indigo-600 dark:text-indigo-400
                    ">${org.projects.length} ${this.msg.projects}</span>
                </div>
                ${org.description ? html `
                    <plugins--markdown-viewer-102020
                        .text=${org.description}
                    ></plugins--markdown-viewer-102020>
                ` : nothing}
            </div>
        `;
    }
    _renderAll() {
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.allTitle, null, this.msg.allDesc)}
                ${this.orgs.length === 0
            ? html `<span class="text-[11px] text-gray-400 dark:text-gray-600 italic">${this.msg.noOrgs}</span>`
            : html `
                        <div class="flex flex-col gap-1.5">
                            ${this.orgs.map((org, i) => this._renderOrgCard(org, i + 1))}
                        </div>
                    `}
                <button
                    class="self-start text-xs text-indigo-500 dark:text-indigo-400 hover:underline"
                    @click=${() => this._dispatchSelect(this.orgs.length + 1)}
                >+ ${this.msg.createNew}</button>
            </div>
        `;
    }
    _renderCustom() {
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.customTitle, null, this.msg.customDesc)}
                <div class="
                    rounded-lg border border-amber-200 dark:border-amber-800/40
                    bg-amber-50 dark:bg-amber-900/10
                    px-3 py-2.5
                ">
                    <span class="text-xs text-amber-600 dark:text-amber-400">${this.msg.inDevelopment}</span>
                </div>
            </div>
        `;
    }
    _renderHeader(title, badge, description) {
        return html `
            <div class="flex flex-col gap-1">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="text-lg font-semibold text-gray-700 dark:text-gray-200">${title}</span>
                    ${badge ? html `
                        <span class="
                            text-[10px] font-mono px-1.5 py-0.5 rounded
                            bg-gray-100 dark:bg-gray-800
                            text-gray-500 dark:text-gray-400
                        ">${badge}</span>
                    ` : nothing}
                </div>
                <span class="text-xs text-gray-400 dark:text-gray-500 leading-relaxed">
                    ${description}
                </span>
            </div>
        `;
    }
    _renderOrgCard(org, selectValue) {
        const clickable = selectValue !== undefined;
        return html `
            <div
                class="
                    rounded-lg border border-gray-200 dark:border-gray-800
                    bg-gray-50 dark:bg-gray-900/50
                    px-3 py-2.5 flex items-center justify-between
                    ${clickable ? 'cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/70 transition-colors' : ''}
                "
                @click=${clickable ? () => this._dispatchSelect(selectValue) : nothing}
            >
                <span class="text-xs font-medium text-gray-700 dark:text-gray-300">${org.name}</span>
                <span class="
                    text-[10px] px-2 py-0.5 rounded-full font-medium
                    bg-indigo-100 dark:bg-indigo-900/30
                    text-indigo-600 dark:text-indigo-400
                ">${org.projects.length} ${this.msg.projects}</span>
            </div>
        `;
    }
    _dispatchSelect(value) {
        this.dispatchEvent(new CustomEvent('select-org', {
            detail: { value },
            bubbles: true,
            composed: true,
        }));
    }
};
__decorate([
    property({ attribute: false })
], PluginSelectOrganization.prototype, "orgs", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectOrganization.prototype, "value", void 0);
PluginSelectOrganization = __decorate([
    customElement('plugins--select-organization-102020')
], PluginSelectOrganization);
export { PluginSelectOrganization };
