/// <mls fileReference="_102020_/l2/plugins/markdownViewer.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
// ─── Component ───────────────────────────────────────────────────────
let PluginMarkdownViewer = class PluginMarkdownViewer extends StateLitElement {
    constructor() {
        super(...arguments);
        this.text = '';
    }
    createRenderRoot() { return this; }
    render() {
        if (!this.text?.trim())
            return html ``;
        return html `
            <div class="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                ${unsafeHTML(this._parse(this.text))}
            </div>
        `;
    }
    _parse(md) {
        let s = md
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        s = s.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
        s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        s = s.replace(/\*(.+?)\*/g, '<em>$1</em>');
        s = s.replace(/`([^`]+)`/g, '<code style="font-family:monospace;background:rgba(128,128,128,0.12);padding:0.1em 0.35em;border-radius:3px">$1</code>');
        s = s.replace(/^### (.+)$/gm, '<div style="font-weight:600;margin-top:0.5em;margin-bottom:0.15em">$1</div>');
        s = s.replace(/^## (.+)$/gm, '<div style="font-weight:700;font-size:1.05em;margin-top:0.6em;margin-bottom:0.15em">$1</div>');
        s = s.replace(/^# (.+)$/gm, '<div style="font-weight:700;font-size:1.15em;margin-top:0.75em;margin-bottom:0.2em">$1</div>');
        s = s.replace(/^[-*] (.+)$/gm, '<div style="padding-left:0.9em">&#8226;&nbsp;$1</div>');
        const paras = s.split(/\n{2,}/);
        s = paras
            .map(p => p.trim())
            .filter(Boolean)
            .map(p => `<p style="margin:0 0 0.4em 0">${p.replace(/\n/g, '<br>')}</p>`)
            .join('');
        return s;
    }
};
__decorate([
    property({ attribute: false })
], PluginMarkdownViewer.prototype, "text", void 0);
PluginMarkdownViewer = __decorate([
    customElement('plugins--markdown-viewer-102020')
], PluginMarkdownViewer);
export { PluginMarkdownViewer };
