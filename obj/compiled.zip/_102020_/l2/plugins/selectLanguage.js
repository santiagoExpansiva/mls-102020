/// <mls fileReference="_102020_/l2/plugins/selectLanguage.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Select Language',
    desc: 'The language defines the locale used for i18n content generation. Each language produces translated variations of the project pages.',
    needsProject: 'Select a project first to see the available languages.',
};
const messages = {
    en: message_en,
    pt: {
        title: 'Selecionar Idioma',
        desc: 'O idioma define o locale usado para geração de conteúdo i18n. Cada idioma produz variações traduzidas das páginas do projeto.',
        needsProject: 'Selecione um projeto primeiro para ver os idiomas disponíveis.',
    },
    es: {
        title: 'Seleccionar Idioma',
        desc: 'El idioma define el locale para la generación de contenido i18n. Cada idioma produce variaciones traducidas de las páginas del proyecto.',
        needsProject: 'Seleccione un proyecto primero para ver los idiomas disponibles.',
    },
};
/// **collab_i18n_end**
// ─── Component ───────────────────────────────────────────────────────
let PluginSelectLanguage = class PluginSelectLanguage extends StateLitElement {
    constructor() {
        super(...arguments);
        this.projectSelected = false;
        this.value = null;
        this.labels = {};
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang];
    }
    get _selectedLabel() {
        if (this.value === null)
            return null;
        return this.labels[this.value] ?? null;
    }
    createRenderRoot() { return this; }
    render() {
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.title, this._selectedLabel, this.msg.desc)}
                ${!this.projectSelected
            ? this._renderNotice(this.msg.needsProject)
            : this.value !== null ? this._renderLangCard() : nothing}
            </div>
        `;
    }
    _renderHeader(title, badge, description) {
        return html `
            <div class="flex flex-col gap-1">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="text-lg font-semibold text-gray-700 dark:text-gray-200">${title}</span>
                    ${badge ? html `
                        <span class="
                            text-[10px] font-mono px-1.5 py-0.5 rounded
                            bg-gray-100 dark:bg-gray-800
                            text-gray-500 dark:text-gray-400
                        ">${badge}</span>
                    ` : nothing}
                </div>
                <span class="text-xs text-gray-400 dark:text-gray-500 leading-relaxed">
                    ${description}
                </span>
            </div>
        `;
    }
    _renderNotice(message) {
        return html `
            <div class="
                rounded-lg border border-amber-200 dark:border-amber-800/40
                bg-amber-50 dark:bg-amber-900/10
                px-3 py-2.5
            ">
                <span class="text-[11px] text-amber-600 dark:text-amber-400 leading-relaxed">
                    ${message}
                </span>
            </div>
        `;
    }
    _renderLangCard() {
        const langCode = this._selectedLabel;
        return html `
            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-2.5 flex items-center gap-2
            ">
                <span class="
                    text-[10px] font-mono px-1.5 py-0.5 rounded
                    bg-emerald-100 dark:bg-emerald-900/30
                    text-emerald-600 dark:text-emerald-400
                    font-semibold uppercase tracking-wider
                ">${langCode}</span>
            </div>
        `;
    }
};
__decorate([
    property({ type: Boolean })
], PluginSelectLanguage.prototype, "projectSelected", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectLanguage.prototype, "value", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectLanguage.prototype, "labels", void 0);
PluginSelectLanguage = __decorate([
    customElement('plugins--select-language-102020')
], PluginSelectLanguage);
export { PluginSelectLanguage };
