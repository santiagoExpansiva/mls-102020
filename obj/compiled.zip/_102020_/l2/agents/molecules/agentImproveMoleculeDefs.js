/// <mls fileReference="_102020_/l2/agents/molecules/agentImproveMoleculeDefs.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { appendLongTermMemory } from '/_102027_/l2/aiAgentHelper.js';
export function createAgent() {
    return {
        agentName: "agentImproveMoleculeDefs",
        agentProject: 102020,
        agentFolder: "agents",
        agentDescription: "Updates molecule defs based on approved improvement requirements",
        visibility: "private",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1
                }, {
                    type: "human",
                    content: context.message.content
                }],
            taskTitle: `Updating defs...`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    const continueIntent = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: args || '',
        systemPrompt: system1
    };
    return [continueIntent];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    const status = 'completed';
    const output = payload.result;
    const fileReference = context.task?.iaCompressed?.longMemory['defsFileReference'] || output.fileReference;
    if (!fileReference)
        throw new Error(`[afterPromptStep] fileReference not found in longMemory or output`);
    await updateExistingDefs(output.skillMd, fileReference, output.group);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    if (context.isTest)
        return [updateStatus];
    const page = context.task?.iaCompressed?.longMemory['page'] || output.fileReference;
    const position = context.task?.iaCompressed?.longMemory['position'] || 'left';
    const prompt = context.task?.iaCompressed?.longMemory['prompt'] || '';
    if (context.task)
        await appendLongTermMemory(context, { group: output.group });
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: 1,
        stepTitle: `Improving molecule: ${fileReference}`,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: "agentNewMoleculeMaterialize",
            prompt: fileReference, //JSON.stringify({ page, prompt, position }),
            rags: null,
        }
    };
    return [newStep, updateStatus];
}
async function updateExistingDefs(skill, fileReference, group) {
    let fileInfo = mls.stor.convertFileReferenceToFile(fileReference);
    if (!fileReference || fileInfo.project < 1)
        throw new Error(`[updateExistingDefs] Invalid fileReference: ${fileReference}`);
    const skillNormalized = skill.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
    const defsFileReference = fileReference.indexOf('.defs.ts') === -1 ? fileReference.replace('.ts', '.defs.ts') : fileReference;
    const template = `/// <mls fileReference="${defsFileReference}" enhancement="_blank" />

// Do not change – automatically generated code.

export const group = '${group}';
export const skill = \`${skillNormalized}\`;

`;
    const params = { ...fileInfo, content: template, extension: '.defs.ts', versionRef: new Date().toISOString() };
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error(`[updateExistingDefs] addOrUpdateFile returned null for: ${fileReference}`);
    const model = await file.getOrCreateModel();
    if (model)
        model.model.setValue(template);
}
const system1 = `
<!-- modelType: codepro -->

You are a planner responsible for updating a skill.md based on approved improvement requirements.

You receive a JSON with updated functional and visual requirements for an existing molecule.
Your task is to rewrite the skill.md to reflect these requirements, preserving existing behaviors not affected by the change.

Follow this structure:

# Metadata
- TagName:

# Objective
A clear description of what the molecule does from a user or system perspective.

# Responsibilities
- Describe observable behaviors only
- Focus on what the molecule must do, not how

# Constraints
- Define rules, limitations, and expected behaviors
- Prevent invalid states or misuse

# Notes
- Optional clarifications about behavior

Strict rules:
- DO NOT include implementation details
- DO NOT mention code, frameworks, or technical solutions
- DO NOT describe how something should be built
- Focus only on behavior and expected outcomes
- Use simple and clear language
- Keep items concise and functional

If any implementation detail is included, remove it and rewrite.

## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "flexible";
        result: IResult
    }

interface IResult {
    fileReference?: string, // deprecated: read from longMemory['defsFileReference'] instead
    group: string,
    skillMd: string,
}
`;
//#endregion
