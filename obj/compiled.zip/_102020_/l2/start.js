/// <mls fileReference="_102020_/l2/start.ts" enhancement="_blank" />
export function start() {
    console.info('start collab aura');
}
