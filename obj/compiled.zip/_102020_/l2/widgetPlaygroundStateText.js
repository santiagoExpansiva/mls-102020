/// <mls fileReference="_102020_/l2/widgetPlaygroundStateText.ts" enhancement="_102020_/l2/enhancementAura.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, property, query } from 'lit/decorators.js';
import { propertyDataSource } from '/_102027_/l2/collabDecorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
let WidgetPlaygroundStateText = class WidgetPlaygroundStateText extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.autocapitalize = "off";
        this.maxlength = undefined;
        this.minlength = undefined;
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.autoCapitalize = undefined;
        this.error = '';
    }
    render() {
        return html `
    <div class="flex flex-col gap-1">
      
      ${this.label ? html `
        <label class="text-sm font-medium text-gray-700 dark:text-gray-300">
          ${this.label}
        </label>
      ` : null}

      <input
        class="
          w-full px-3 py-2 rounded-lg border
          text-sm text-gray-900 dark:text-gray-100
          bg-white dark:bg-slate-800
          border-gray-300 dark:border-slate-600
          transition
          outline-none
          
          focus:ring-2 focus:ring-blue-500 focus:border-blue-500
          dark:focus:ring-blue-400 dark:focus:border-blue-400
          
          disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed
          dark:disabled:bg-slate-700 dark:disabled:text-slate-500
          
          placeholder:text-gray-400 dark:placeholder:text-slate-500
          
          ${this.error ? 'border-red-500 focus:ring-red-500 focus:border-red-500 dark:border-red-400 dark:focus:ring-red-400 dark:focus:border-red-400' : ''}
        "
        type="text"
        name=${ifDefined(this.name)}
        ?disabled=${this.disabled}
        ?readonly=${this.readonly}
        ?required=${this.required}
        maxlength=${ifDefined(this.maxlength)}    
        minlength=${ifDefined(this.minlength)}
        autocomplete=${ifDefined(this.autocomplete)}
        placeholder=${ifDefined(this.placeholder)}
        .value=${this.value || ''}
        ?autofocus=${this.autofocus}
        pattern=${ifDefined(this.pattern)}
        @input=${this.handleChange}
      />

      ${this.hint ? html `
        <small class="text-xs text-gray-500 dark:text-gray-400">
          ${this.hint}
        </small>
      ` : null}

      ${this.error ? html `
        <div class="text-xs text-red-500 dark:text-red-400 font-medium">
          ${this.error}
        </div>
      ` : null}

    </div>
  `;
    }
    handleChange(event) {
        const input = event.target;
        this.value = input.value;
    }
};
__decorate([
    propertyDataSource({ type: String })
], WidgetPlaygroundStateText.prototype, "value", void 0);
__decorate([
    property({ type: String })
], WidgetPlaygroundStateText.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], WidgetPlaygroundStateText.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WidgetPlaygroundStateText.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WidgetPlaygroundStateText.prototype, "errormessage", void 0);
__decorate([
    property({ type: String })
], WidgetPlaygroundStateText.prototype, "placeholder", void 0);
__decorate([
    property({ type: String })
], WidgetPlaygroundStateText.prototype, "autocomplete", void 0);
__decorate([
    property({ type: Number })
], WidgetPlaygroundStateText.prototype, "maxlength", void 0);
__decorate([
    property({ type: Number })
], WidgetPlaygroundStateText.prototype, "minlength", void 0);
__decorate([
    property({ type: Boolean })
], WidgetPlaygroundStateText.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WidgetPlaygroundStateText.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WidgetPlaygroundStateText.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WidgetPlaygroundStateText.prototype, "autofocus", void 0);
__decorate([
    propertyDataSource({ type: String })
], WidgetPlaygroundStateText.prototype, "hint", void 0);
__decorate([
    property({ type: String })
], WidgetPlaygroundStateText.prototype, "autoCapitalize", void 0);
__decorate([
    query('.input_control')
], WidgetPlaygroundStateText.prototype, "input", void 0);
WidgetPlaygroundStateText = __decorate([
    customElement('widget-playground-state-text-102020')
], WidgetPlaygroundStateText);
export { WidgetPlaygroundStateText };
