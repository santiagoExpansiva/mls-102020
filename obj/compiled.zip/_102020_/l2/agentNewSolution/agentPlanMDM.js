/// <mls fileReference="_102020_/l2/agentNewSolution/agentPlanMDM.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, assertString, createPlannerPromptReadyIntent, createPlannerVariableToolSchema, createPlannerUpdateStatusIntent, extractPlannerOutput, getPlannerOutput, } from '/_102020_/l2/agentNewSolution/agentPlanningShared.js';
import { saveNewSolutionAgentTracePayload, saveNewSolutionPlanArtifacts } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
import { getFinalizeSolutionPlanOutput } from '/_102020_/l2/agentNewSolution/agentFinalizeSolutionPlan.js';
export function createAgent() {
    return {
        agentName: 'agentPlanMDM',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Plan mandatory MDM domains for the final solution',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
export const PLAN_MDM_TOOL_NAME = 'submitMdmPlan';
export const PLAN_MDM_STEP_ID = '09-plan-mdm';
const PLAN_MDM_ALIASES = [PLAN_MDM_STEP_ID, 'plan-mdm'];
const planMdmToolSchema = createPlannerVariableToolSchema(PLAN_MDM_TOOL_NAME, 'Submit mandatory MDM planning for the newSolution final plan.', {
    type: 'object',
    additionalProperties: false,
    required: ['mdmDomains'],
    properties: {
        mdmDomains: {
            type: 'array',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['domainId', 'title', 'masterEntities', 'sourceOfTruth', 'consumers', 'governanceRules'],
                properties: {
                    domainId: { type: 'string' },
                    title: { type: 'string' },
                    masterEntities: { type: 'array', items: { type: 'string' } },
                    sourceOfTruth: { type: 'string' },
                    consumers: { type: 'array', items: { type: 'string' } },
                    governanceRules: { type: 'array', items: { type: 'string' } },
                },
            },
        },
    },
});
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!agent || !step)
        throw new Error('[agentPlanMDM](beforePromptStep) invalid params');
    if (!args)
        throw new Error(`[${agent.agentName}](beforePromptStep) args invalid`);
    if (!context.task)
        throw new Error(`[${agent.agentName}](beforePromptStep) task invalid`);
    const finalPlan = getFinalizeSolutionPlanOutput(context);
    return [
        createPlannerPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(PLAN_MDM_TOOL_NAME), buildHumanPrompt(args, finalPlan), planMdmToolSchema, PLAN_MDM_TOOL_NAME),
    ];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    let output;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        output = extractPlanMDMOutput(payload);
        validatePlanMDMOutput(output);
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = 'agentPlanMDM returned status failed';
        }
        else if (output.status === 'needs_input') {
            traceMsg = 'agentPlanMDM returned status needs_input; keeping MDM draft.';
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}](afterPromptStep) ${traceMsg}`);
    }
    await saveNewSolutionAgentTracePayload(context, agent.agentName, step);
    // TODO-FINAL-015: persist MDM domains (draft l5/{domainId}/module.defs.ts or manifest reference).
    if (status === 'completed' && output)
        await saveNewSolutionPlanArtifacts(context, agent.agentName, step, output);
    return [createPlannerUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, status === 'completed' ? 'input' : undefined)];
}
export function getPlanMDMOutput(context) {
    return getPlannerOutput(context, 'agentPlanMDM', planMDMConfig, validatePlanMDMOutput);
}
function extractPlanMDMOutput(payload) {
    return extractPlannerOutput(payload, planMDMConfig);
}
const planMDMConfig = {
    toolName: PLAN_MDM_TOOL_NAME,
    stepId: PLAN_MDM_STEP_ID,
    stepIdAliases: PLAN_MDM_ALIASES,
    normalizeResult: normalizePlanMDMResult,
};
function normalizePlanMDMResult(value) {
    const result = assertRecord(value, 'result');
    return {
        mdmDomains: assertArray(result.mdmDomains, 'result.mdmDomains').map((item, index) => normalizeMdmDomain(item, `result.mdmDomains[${index}]`)),
    };
}
function normalizeMdmDomain(value, path) {
    const domain = assertRecord(value, path);
    return {
        domainId: assertString(domain.domainId, `${path}.domainId`),
        title: assertString(domain.title, `${path}.title`),
        masterEntities: assertArray(domain.masterEntities, `${path}.masterEntities`).map((item, index) => assertString(item, `${path}.masterEntities[${index}]`)),
        sourceOfTruth: assertString(domain.sourceOfTruth, `${path}.sourceOfTruth`),
        consumers: assertArray(domain.consumers, `${path}.consumers`).map((item, index) => assertString(item, `${path}.consumers[${index}]`)),
        governanceRules: assertArray(domain.governanceRules, `${path}.governanceRules`).map((item, index) => assertString(item, `${path}.governanceRules[${index}]`)),
    };
}
function validatePlanMDMOutput(output) {
    if (output.status === 'ok' && output.result.mdmDomains.length === 0)
        throw new Error('MDM is mandatory and mdmDomains must not be empty');
    if (output.status === 'needs_input' && output.questions.length === 0)
        throw new Error('needs_input MDM plan must include questions');
}
function buildHumanPrompt(args, finalPlan) {
    return `## Planned step args
${args}

## Final solution plan
${JSON.stringify(finalPlan, null, 2)}

## MDM policy
${JSON.stringify(mdmPolicy, null, 2)}
`;
}
const mdmPolicy = {
    schemaVersion: '2026-06-02',
    required: true,
    rules: [
        'Every solution must define at least one master data domain.',
        'Every master data entity must declare sourceOfTruth.',
        'Every consumer artifact must reference the master data entity instead of duplicating it.',
        'Customer-like and asset-like entities are strong MDM candidates.',
    ],
    defaultDomains: ['customer', 'asset', 'productOrService', 'organization'],
};
const systemPrompt = `
<!-- modelType: codepro -->
<!-- x-tool-strict: true -->

You are agentPlanMDM for the collab.codes "newSolution" flow.
Plan mandatory MDM for the final solution plan.
Use the same language as the user for titles, reasons, questions, and trace.
Use English camelCase identifiers for domainId.

## Tool mode
Call the "{{toolName}}" tool with only these top-level arguments: status, result, questions, and trace. Put questions and trace beside result, never inside result. Do not include type, runId, stepId, schemaVersion, toolName, or arguments; the harness fills those fields.
Do not return prose.

## Rules
- Include customer, account, person, supplier, tenant, subscriber, buyer, patient, or similar party MDM when the solution has external parties.
- Include product, asset, service, location, staff, category, store, or organization MDM when those records are stable master data in the requested domain.
- MDM is mandatory, but its domains must be inferred from the ontology and final plan.
- Do not hard-code sample fixture entities.
- Declare sourceOfTruth and consumers.
- Reference pages, workflows, plugins, agents, usecases, and metric tables that consume the master data when known.
`;
