/// <mls fileReference="_102020_/l2/agentNewSolution/agentDiscoverSolutionScope.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAgentStepByAgentName, getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { saveNewSolutionAgentTracePayload } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
export function createAgent() {
    return {
        agentName: 'agentDiscoverSolutionScope',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Discover the likely scope and artifact needs for a new solution',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
export const DISCOVER_SOLUTION_SCOPE_TOOL_NAME = 'submitSolutionScopeDraft';
export const DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION = '2026-06-02';
export const DISCOVER_SOLUTION_SCOPE_STEP_ID = '03-discover-scope';
const DISCOVER_SOLUTION_SCOPE_STEP_ID_ALIASES = [DISCOVER_SOLUTION_SCOPE_STEP_ID, 'req-discover-scope'];
const DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION_ALIASES = [DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION, '1.0'];
export const discoverSolutionScopeToolSchema = {
    type: 'function',
    function: {
        name: DISCOVER_SOLUTION_SCOPE_TOOL_NAME,
        description: 'Submit a validated scope draft for the newSolution planner.',
        parameters: {
            type: 'object',
            additionalProperties: false,
            required: ['status', 'result', 'questions', 'trace'],
            properties: {
                status: { enum: ['ok', 'needs_input', 'failed'] },
                result: {
                    type: 'object',
                    additionalProperties: false,
                    required: ['domain', 'summary', 'actors', 'capabilities', 'artifactSignals', 'businessRisks', 'missingContext'],
                    properties: {
                        domain: { type: 'string' },
                        summary: { type: 'string' },
                        actors: {
                            type: 'array',
                            items: {
                                type: 'object',
                                additionalProperties: false,
                                required: ['actorId', 'description'],
                                properties: {
                                    actorId: { type: 'string' },
                                    title: { type: 'string' },
                                    description: { type: 'string' },
                                },
                            },
                        },
                        capabilities: {
                            type: 'array',
                            items: {
                                type: 'object',
                                additionalProperties: false,
                                required: ['capabilityId', 'actor', 'priority'],
                                properties: {
                                    capabilityId: { type: 'string' },
                                    title: { type: 'string' },
                                    description: { type: 'string' },
                                    actor: { type: 'string' },
                                    priority: { enum: ['now', 'soon', 'later', 'never'] },
                                },
                            },
                        },
                        artifactSignals: {
                            type: 'object',
                            additionalProperties: false,
                            required: ['pages', 'workflows', 'plugins', 'agents', 'horizontalModules', 'mdm', 'metrics', 'usecases'],
                            properties: {
                                pages: { type: 'array', items: { $ref: '#/$defs/artifactSignal' } },
                                workflows: { type: 'array', items: { $ref: '#/$defs/artifactSignal' } },
                                plugins: { type: 'array', items: { $ref: '#/$defs/artifactSignal' } },
                                agents: { type: 'array', items: { $ref: '#/$defs/artifactSignal' } },
                                horizontalModules: { type: 'array', items: { $ref: '#/$defs/artifactSignal' } },
                                mdm: { type: 'array', items: { $ref: '#/$defs/artifactSignal' } },
                                metrics: { type: 'array', items: { $ref: '#/$defs/artifactSignal' } },
                                usecases: { type: 'array', items: { $ref: '#/$defs/artifactSignal' } },
                            },
                        },
                        businessRisks: { type: 'array', items: { type: 'string' } },
                        missingContext: { type: 'array', items: { type: 'string' } },
                    },
                },
                questions: { type: 'array', items: { type: 'string' } },
                trace: { type: 'array', items: { type: 'string' } },
            },
            $defs: {
                artifactSignal: {
                    type: 'object',
                    additionalProperties: false,
                    required: ['signal', 'reason'],
                    properties: {
                        signal: { type: 'string' },
                        title: { type: 'string' },
                        actor: { type: 'string' },
                        reason: { type: 'string' },
                        priority: { enum: ['now', 'soon', 'later', 'never'] },
                        mdmKind: { type: 'string' },
                    },
                },
            },
        },
    },
};
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    if (!context.task)
        throw new Error(`(${agent.agentName})[beforePromptStep] task invalid`);
    const initialPlan = getInitialNewSolutionPlanSummary(context);
    const clarificationAnswer = getRequirementsClarificationAnswer(context);
    const continueIntent = {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task.PK,
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: buildSystemPrompt(),
        humanPrompt: buildHumanPrompt(args, initialPlan, clarificationAnswer),
        tools: [discoverSolutionScopeToolSchema],
        toolChoice: {
            type: 'function',
            function: { name: DISCOVER_SOLUTION_SCOPE_TOOL_NAME },
        },
    };
    return [continueIntent];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params`);
    const payload = step.interaction?.payload?.[0];
    let status = 'completed';
    let traceMsg;
    try {
        if (!payload)
            throw new Error('missing payload');
        const output = extractDiscoverSolutionScopeOutput(payload);
        const requirementsAnswer = context.task ? getRequirementsClarificationAnswer(context) : undefined;
        validateDiscoverSolutionScopeOutput(output, { initialMetricsRequested: wantsInitialMetricsDashboard(requirementsAnswer) });
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = 'agentDiscoverSolutionScope returned status failed';
        }
        else if (output.status === 'needs_input') {
            traceMsg = 'agentDiscoverSolutionScope returned status needs_input; keeping the validated draft and continuing with questions/missingContext.';
        }
    }
    catch (error) {
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}](afterPromptStep) ${traceMsg}`);
        status = 'failed';
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
    };
    if (status === 'completed')
        updateStatus.cleaner = 'input';
    await saveNewSolutionAgentTracePayload(context, agent.agentName, step);
    return [updateStatus];
}
function buildSystemPrompt() {
    return systemPrompt
        .split('{{toolName}}').join(DISCOVER_SOLUTION_SCOPE_TOOL_NAME);
}
function buildHumanPrompt(args, initialPlan, clarificationAnswer) {
    return `## Planned step args
${args}

## Initial user prompt
${initialPlan.userPrompt}

## Initial new solution plan
${JSON.stringify(initialPlan, null, 2)}

## First clarification answer
${JSON.stringify(clarificationAnswer, null, 2)}
`;
}
function createSignalFromString(value) {
    return {
        signal: toCamelSignal(value),
        reason: value,
    };
}
function createCapabilityFromString(value) {
    return {
        capabilityId: toCamelSignal(value),
        actor: 'unknown',
        priority: 'now',
        title: value,
    };
}
function createActorFromString(value) {
    return {
        actorId: toCamelSignal(value),
        title: value,
        description: value,
    };
}
export function extractDiscoverSolutionScopeOutput(payload) {
    const value = parseMaybeJson(payload);
    if (!isRecord(value))
        throw new Error('tool payload must be an object');
    if (value.type === 'result')
        throw new Error(String(value.result || 'agent returned result error'));
    const directOutput = tryNormalizeOutput(value);
    if (directOutput)
        return directOutput;
    if (value.type === 'flexible') {
        const flexibleResult = parseMaybeJson(value.result);
        const outputFromFlexibleResult = tryNormalizeOutput(flexibleResult);
        if (outputFromFlexibleResult)
            return outputFromFlexibleResult;
        const variableOutputFromFlexibleResult = tryNormalizeVariableOutput(flexibleResult);
        if (variableOutputFromFlexibleResult)
            return variableOutputFromFlexibleResult;
        const outputFromFlexibleTool = tryExtractToolArguments(flexibleResult);
        if (outputFromFlexibleTool)
            return outputFromFlexibleTool;
    }
    const outputFromTool = tryExtractToolArguments(value);
    if (outputFromTool)
        return outputFromTool;
    const outputFromOpenAIToolCall = tryExtractOpenAIToolCall(value);
    if (outputFromOpenAIToolCall)
        return outputFromOpenAIToolCall;
    throw new Error('payload does not contain a recognized tool call or flexible scope output');
}
function tryExtractOpenAIToolCall(value) {
    const toolCalls = value.tool_calls;
    if (!Array.isArray(toolCalls) || toolCalls.length === 0)
        return null;
    const call = toolCalls.find(item => {
        const record = isRecord(item) ? item : null;
        const fn = record && isRecord(record.function) ? record.function : null;
        return fn?.name === DISCOVER_SOLUTION_SCOPE_TOOL_NAME;
    });
    if (!isRecord(call))
        return null;
    const fn = call.function;
    if (!isRecord(fn))
        return null;
    return normalizeToolArguments(fn.arguments);
}
function tryExtractToolArguments(value) {
    const record = parseMaybeJson(value);
    if (!isRecord(record))
        return null;
    if (record.toolName !== DISCOVER_SOLUTION_SCOPE_TOOL_NAME)
        return null;
    return normalizeToolArguments(record.arguments);
}
function normalizeToolArguments(value) {
    const args = parseMaybeJson(value);
    if (!isRecord(args))
        throw new Error('tool arguments must be an object');
    const directOutput = tryNormalizeOutput(args);
    if (directOutput)
        return directOutput;
    const variableOutput = tryNormalizeVariableOutput(args);
    if (variableOutput)
        return variableOutput;
    const output = tryNormalizeOutput(parseMaybeJson(args.result));
    if (output)
        return output;
    throw new Error('tool arguments do not contain a flexible scope output');
}
function tryNormalizeVariableOutput(value) {
    const output = parseMaybeJson(value);
    if (!isRecord(output))
        return null;
    if (output.runId !== undefined || output.stepId !== undefined || output.schemaVersion !== undefined || output.type !== undefined)
        return null;
    if (output.status === undefined || output.result === undefined)
        return null;
    return normalizeDiscoverSolutionScopeOutput({
        runId: 'provider-tool-call',
        stepId: DISCOVER_SOLUTION_SCOPE_STEP_ID,
        schemaVersion: DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION,
        status: output.status,
        result: output.result,
        questions: output.questions,
        trace: output.trace,
    });
}
function tryNormalizeOutput(value) {
    const output = parseMaybeJson(value);
    if (!isRecord(output))
        return null;
    if (!isKnownScopeStepId(output.stepId) || !isKnownScopeSchemaVersion(output.schemaVersion))
        return null;
    return normalizeDiscoverSolutionScopeOutput(output);
}
function normalizeDiscoverSolutionScopeOutput(value) {
    const result = assertRecord(value.result, 'result');
    const artifactSignals = assertRecord(result.artifactSignals, 'result.artifactSignals');
    return {
        runId: assertString(value.runId, 'runId'),
        stepId: normalizeScopeStepId(value.stepId, 'stepId'),
        schemaVersion: normalizeScopeSchemaVersion(value.schemaVersion, 'schemaVersion'),
        status: assertStatus(value.status, 'status'),
        result: {
            domain: assertString(result.domain, 'result.domain'),
            summary: assertString(result.summary, 'result.summary'),
            actors: normalizeActors(result.actors, 'result.actors'),
            capabilities: normalizeCapabilities(result.capabilities, 'result.capabilities'),
            artifactSignals: {
                pages: normalizeSignals(artifactSignals.pages, 'result.artifactSignals.pages'),
                workflows: normalizeSignals(artifactSignals.workflows, 'result.artifactSignals.workflows'),
                plugins: normalizeSignals(artifactSignals.plugins, 'result.artifactSignals.plugins'),
                agents: normalizeSignals(artifactSignals.agents, 'result.artifactSignals.agents'),
                horizontalModules: normalizeSignals(artifactSignals.horizontalModules, 'result.artifactSignals.horizontalModules'),
                mdm: normalizeSignals(artifactSignals.mdm, 'result.artifactSignals.mdm'),
                metrics: normalizeSignals(artifactSignals.metrics, 'result.artifactSignals.metrics'),
                usecases: normalizeSignals(artifactSignals.usecases, 'result.artifactSignals.usecases'),
            },
            businessRisks: assertStringArray(result.businessRisks, 'result.businessRisks'),
            missingContext: assertStringArray(result.missingContext, 'result.missingContext'),
        },
        questions: normalizeStringList(value.questions, 'questions'),
        trace: normalizeStringList(value.trace, 'trace'),
    };
}
function isKnownScopeStepId(value) {
    return DISCOVER_SOLUTION_SCOPE_STEP_ID_ALIASES.includes(value);
}
function isKnownScopeSchemaVersion(value) {
    return DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION_ALIASES.includes(value);
}
function normalizeScopeStepId(value, path) {
    if (isKnownScopeStepId(value))
        return DISCOVER_SOLUTION_SCOPE_STEP_ID;
    throw new Error(`${path} must be ${DISCOVER_SOLUTION_SCOPE_STEP_ID}`);
}
function normalizeScopeSchemaVersion(value, path) {
    if (isKnownScopeSchemaVersion(value))
        return DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION;
    throw new Error(`${path} must be ${DISCOVER_SOLUTION_SCOPE_SCHEMA_VERSION}`);
}
function validateDiscoverSolutionScopeOutput(output, options) {
    if (output.status === 'ok' && output.result.artifactSignals.mdm.length === 0) {
        throw new Error('MDM is mandatory and artifactSignals.mdm must not be empty');
    }
    if (output.status === 'ok' && options.initialMetricsRequested && output.result.artifactSignals.metrics.length === 0) {
        throw new Error('initial metrics/dashboard was requested, but artifactSignals.metrics is empty');
    }
    if (output.status === 'needs_input' && output.questions.length === 0 && output.result.missingContext.length === 0) {
        throw new Error('needs_input output must include questions or missingContext');
    }
}
function normalizeActors(value, path) {
    if (!Array.isArray(value))
        throw new Error(`${path} must be an array`);
    return value.map((item, index) => {
        if (typeof item === 'string')
            return createActorFromString(item);
        const record = assertRecord(item, `${path}[${index}]`);
        return {
            actorId: assertString(record.actorId, `${path}[${index}].actorId`),
            title: optionalString(record.title, `${path}[${index}].title`),
            description: assertString(record.description, `${path}[${index}].description`),
        };
    });
}
function normalizeCapabilities(value, path) {
    if (!Array.isArray(value))
        throw new Error(`${path} must be an array`);
    return value.map((item, index) => {
        if (typeof item === 'string')
            return createCapabilityFromString(item);
        const record = assertRecord(item, `${path}[${index}]`);
        return {
            capabilityId: assertString(record.capabilityId, `${path}[${index}].capabilityId`),
            title: optionalString(record.title, `${path}[${index}].title`),
            description: optionalString(record.description, `${path}[${index}].description`),
            actor: assertString(record.actor, `${path}[${index}].actor`),
            priority: assertPriority(record.priority, `${path}[${index}].priority`),
        };
    });
}
function normalizeSignals(value, path) {
    if (!Array.isArray(value))
        throw new Error(`${path} must be an array`);
    return value.map((item, index) => {
        if (typeof item === 'string')
            return createSignalFromString(item);
        const record = assertRecord(item, `${path}[${index}]`);
        return {
            signal: assertString(record.signal, `${path}[${index}].signal`),
            title: optionalString(record.title, `${path}[${index}].title`),
            actor: optionalString(record.actor, `${path}[${index}].actor`),
            reason: assertString(record.reason, `${path}[${index}].reason`),
            priority: optionalPriority(record.priority, `${path}[${index}].priority`),
            mdmKind: optionalString(record.mdmKind, `${path}[${index}].mdmKind`),
        };
    });
}
function getInitialNewSolutionPlanSummary(context) {
    if (!context.task)
        throw new Error('[getInitialNewSolutionPlanSummary] task invalid');
    const agentStep = getAgentStepByAgentName(context.task, 'agentNewSolution');
    const payload = agentStep?.interaction?.payload?.[0];
    const result = payload?.type === 'flexible' ? payload.result : undefined;
    if (!result || typeof result !== 'object')
        throw new Error('[getInitialNewSolutionPlanSummary] initial plan not found');
    if (!result.userPrompt || typeof result.userPrompt !== 'string')
        throw new Error('[getInitialNewSolutionPlanSummary] user prompt not found');
    return result;
}
function getRequirementsClarificationAnswer(context) {
    if (!context.task)
        throw new Error('[getRequirementsClarificationAnswer] task invalid');
    const allSteps = getAllSteps(context.task.iaCompressed?.nextSteps);
    const answerStep = allSteps.find(item => item.type === 'result' &&
        item.planning?.planId === 'req-clarification-answer' &&
        item.result);
    if (!answerStep?.result)
        throw new Error('[getRequirementsClarificationAnswer] clarification answer not found');
    const parsed = JSON.parse(answerStep.result);
    if (!parsed.answers || typeof parsed.answers !== 'object')
        throw new Error('[getRequirementsClarificationAnswer] invalid clarification answer');
    return parsed;
}
export function wantsInitialMetricsDashboard(answer) {
    const raw = answer?.answers?.initialMetricsDashboard;
    if (raw === undefined)
        return false;
    if (raw === false)
        return false;
    if (raw === true)
        return true;
    const value = Array.isArray(raw) ? raw.join(' ') : String(raw);
    const normalized = normalizeText(value);
    if (/\b(none|no|nao|later|depois|futuro|sem)\b/.test(normalized))
        return false;
    return /\b(sim|yes|basic|basico|metric|dashboard|painel)\b/.test(normalized);
}
function normalizeText(value) {
    return value
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase();
}
function toCamelSignal(value) {
    const words = normalizeText(value)
        .replace(/[^a-z0-9]+/g, ' ')
        .trim()
        .split(/\s+/)
        .filter(Boolean);
    if (words.length === 0)
        return 'signal';
    return words
        .map((word, index) => index === 0 ? word : `${word.charAt(0).toUpperCase()}${word.slice(1)}`)
        .join('');
}
function parseMaybeJson(value) {
    if (typeof value !== 'string')
        return value;
    const trimmed = value.trim();
    if (!trimmed)
        return value;
    if (!trimmed.startsWith('{') && !trimmed.startsWith('['))
        return value;
    return JSON.parse(trimmed);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function assertRecord(value, path) {
    if (!isRecord(value))
        throw new Error(`${path} must be an object`);
    return value;
}
function assertString(value, path) {
    if (typeof value !== 'string' || value.trim().length === 0)
        throw new Error(`${path} must be a non-empty string`);
    return value.trim();
}
function optionalString(value, path) {
    if (value === undefined || value === null || value === '')
        return undefined;
    return assertString(value, path);
}
function assertStringArray(value, path) {
    if (!Array.isArray(value))
        throw new Error(`${path} must be an array`);
    return value.map((item, index) => assertString(item, `${path}[${index}]`));
}
function normalizeStringList(value, path) {
    if (value === undefined || value === null)
        return [];
    if (Array.isArray(value))
        return value.map((item, index) => normalizeStringListItem(item, `${path}[${index}]`));
    if (isRecord(value)) {
        return Object.entries(value).map(([key, item]) => {
            const normalized = normalizeStringListItem(item, `${path}.${key}`);
            return normalized || key;
        });
    }
    return [assertString(value, path)];
}
function normalizeStringListItem(value, path) {
    if (typeof value === 'string')
        return assertString(value, path);
    if (typeof value === 'number' || typeof value === 'boolean')
        return String(value);
    if (isRecord(value)) {
        const parts = [
            optionalString(value.title, `${path}.title`),
            optionalString(value.question, `${path}.question`),
            optionalString(value.description, `${path}.description`),
            optionalString(value.reason, `${path}.reason`),
        ].filter((item) => !!item);
        if (parts.length > 0)
            return parts.join(' - ');
        return JSON.stringify(value);
    }
    throw new Error(`${path} must be a string-compatible value`);
}
function assertStatus(value, path) {
    if (value === 'ok' || value === 'needs_input' || value === 'failed')
        return value;
    throw new Error(`${path} must be ok, needs_input, or failed`);
}
function assertPriority(value, path) {
    if (value === 'now' || value === 'soon' || value === 'later' || value === 'never')
        return value;
    throw new Error(`${path} must be now, soon, later, or never`);
}
function optionalPriority(value, path) {
    if (value === undefined || value === null || value === '')
        return undefined;
    return assertPriority(value, path);
}
const systemPrompt = `
<!-- modelType: codeinstruct -->

You are agentDiscoverSolutionScope for the collab.codes "newModule" flow.

Analyze the original user prompt and the first clarification answer.
Your goal is to identify what kinds of artifacts this solution probably needs.

Use the same language as the user for titles, descriptions, reasons, risks, questions, and trace.
Use English camelCase identifiers for domain, actorId, capabilityId, and artifact signal IDs.

## Tool mode

Call the "{{toolName}}" tool with only these top-level arguments: status, result, questions, and trace. Put questions and trace beside result, never inside result. Do not include type, runId, stepId, schemaVersion, toolName, or arguments; the harness fills those fields.
Do not return prose.

## Rules

- The tool arguments must satisfy the provided schema.
- Always include result.summary: a short (1-3 sentence) overview of the requested solution, in the user's language. Never omit it, even when status is "needs_input".
- MDM is mandatory. Always include at least one MDM signal and explain why it is needed.
- If the clarification answer requests initial metrics/dashboard, include metrics and admin dashboard signals.
- Identify backend use case needs when the solution has writes, lifecycle transitions, BFF commands, metric updates, or aggregate maintenance.
- Differentiate static pages from workflows.
- Detect external integrations only when the prompt or clarification implies them.
- Do not use hard-coded domain assumptions. Infer required domain actions from the requested solution.
- When the domain contains a booking, order, request, subscription, approval, service request, or similar commitment (sometimes called reservation or rental in specific domains), identify the main subject/resource/item/service being committed and the user action that selects or confirms it. Use names from the actual prompt and ontology.
- Use status "needs_input" only when the scope cannot be safely drafted without another client decision; then include questions or missingContext.
- Use status "failed" only for structural impossibility.
`;
export function getDiscoverSolutionScopeOutput(context) {
    if (!context.task)
        throw new Error('[getDiscoverSolutionScopeOutput] task invalid');
    const agentStep = getAgentStepByAgentName(context.task, 'agentDiscoverSolutionScope');
    if (!agentStep)
        throw new Error('[getDiscoverSolutionScopeOutput] scope agent step not found');
    const payload = agentStep.interaction?.payload?.[0];
    if (!payload)
        throw new Error('[getDiscoverSolutionScopeOutput] scope payload not found');
    const output = extractDiscoverSolutionScopeOutput(payload);
    validateDiscoverSolutionScopeOutput(output, {
        initialMetricsRequested: wantsInitialMetricsDashboard(getRequirementsClarificationAnswer(context)),
    });
    return output;
}
export function getDiscoverSolutionScopeDraft(context) {
    return getDiscoverSolutionScopeOutput(context).result;
}
