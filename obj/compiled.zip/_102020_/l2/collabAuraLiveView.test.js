/// <mls fileReference="_102020_/l2/collabAuraLiveView.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
