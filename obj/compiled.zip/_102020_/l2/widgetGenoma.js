/// <mls fileReference="_102020_/l2/widgetGenoma.ts" enhancement="_102020_/l2/enhancementAura.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { mutationGroups, renderIcon } from '/_102020_/l2/molecules/index.js';
import { convertFileToTag, resolveTagToFile } from '/_102020_/l2/utils.js';
import '/_102027_/l2/collabSelectKnob.js';
// =============================================================================
// WIDGET GENOMA — Mutation Testing Service
// =============================================================================
// Two views in one service:
//   1. Group Selection Grid — pick a skill group
//   2. Knob View — rotate between widgets of the selected group
let WidgetGenoma102020 = class WidgetGenoma102020 extends StateLitElement {
    constructor() {
        // =========================================================================
        // STATE
        // =========================================================================
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-genoma-102020 .genoma-root {
  font-family: var(--font-family-primary);
  color: var(--text-primary-color);
  min-height: 100%;
}
widget-genoma-102020 .genoma-grid-view {
  padding: var(--space-32) var(--space-24);
  max-width: 960px;
  margin: 0 auto;
}
widget-genoma-102020 .genoma-header {
  margin-bottom: var(--space-32);
}
widget-genoma-102020 .genoma-title {
  font-size: var(--font-size-24);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary-color-darker);
  margin: 0 0 var(--space-8) 0;
  line-height: var(--line-height-small);
}
widget-genoma-102020 .genoma-subtitle {
  font-size: var(--font-size-16);
  color: var(--text-primary-color-lighter);
  margin: 0;
  line-height: var(--line-height-medium);
}
widget-genoma-102020 .genoma-filters {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-8);
  margin-bottom: var(--space-24);
}
widget-genoma-102020 .genoma-filter-chip {
  display: inline-flex;
  align-items: center;
  padding: 6px 14px;
  font-size: var(--font-size-12);
  font-family: var(--font-family-primary);
  font-weight: var(--font-weight-normal);
  color: var(--text-primary-color-lighter);
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color);
  border-radius: 20px;
  cursor: pointer;
  transition: all var(--transition-slow) ease;
  outline: none;
}
widget-genoma-102020 .genoma-filter-chip:hover {
  background: var(--bg-secondary-color-lighter);
  border-color: var(--grey-color-dark);
  color: var(--text-primary-color);
}
widget-genoma-102020 .genoma-filter-chip.active {
  background: var(--text-secondary-color);
  border-color: var(--text-secondary-color);
  color: var(--bg-primary-color);
  font-weight: var(--font-weight-bold);
}
widget-genoma-102020 .genoma-card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: var(--space-16);
}
widget-genoma-102020 .genoma-card {
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
  padding: var(--space-16);
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color);
  border-radius: 10px;
  cursor: pointer;
  transition: all var(--transition-slow) ease;
  position: relative;
  overflow: hidden;
}
widget-genoma-102020 .genoma-card:hover {
  border-color: var(--text-secondary-color-lighter);
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
  transform: translateY(-2px);
}
widget-genoma-102020 .genoma-card:hover .genoma-card-icon {
  color: var(--text-secondary-color);
}
widget-genoma-102020 .genoma-card:active {
  transform: translateY(0);
}
widget-genoma-102020 .genoma-card-icon {
  color: var(--text-primary-color-lighter);
  transition: color var(--transition-slow) ease;
  line-height: 0;
}
widget-genoma-102020 .genoma-card-icon svg {
  display: block;
}
widget-genoma-102020 .genoma-card-body {
  flex: 1;
}
widget-genoma-102020 .genoma-card-label {
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary-color);
  margin-bottom: 4px;
  line-height: var(--line-height-small);
}
widget-genoma-102020 .genoma-card-desc {
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
  line-height: var(--line-height-medium);
}
widget-genoma-102020 .genoma-card-badge {
  display: inline-block;
  align-self: flex-start;
  padding: 2px 10px;
  font-size: 10px;
  font-weight: var(--font-weight-bold);
  color: var(--text-secondary-color);
  background: rgba(28, 145, 205, 0.08);
  border-radius: 12px;
  letter-spacing: 0.02em;
}
widget-genoma-102020 .genoma-knob-view {
  min-height: 100%;
  display: flex;
  flex-direction: column;
}
widget-genoma-102020 .genoma-topbar {
  display: flex;
  align-items: center;
  gap: var(--space-16);
  padding: var(--space-16) var(--space-24);
  border-bottom: 1px solid var(--grey-color);
  background: var(--bg-primary-color);
}
widget-genoma-102020 .genoma-back-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  font-size: var(--font-size-12);
  font-family: var(--font-family-primary);
  font-weight: var(--font-weight-normal);
  color: var(--text-primary-color-lighter);
  background: transparent;
  border: 1px solid var(--grey-color);
  border-radius: 6px;
  cursor: pointer;
  transition: all var(--transition-slow) ease;
  outline: none;
}
widget-genoma-102020 .genoma-back-btn:hover {
  background: var(--bg-secondary-color-lighter);
  color: var(--text-primary-color);
  border-color: var(--grey-color-dark);
}
widget-genoma-102020 .genoma-back-btn svg {
  display: block;
}
widget-genoma-102020 .genoma-topbar-title {
  display: flex;
  align-items: center;
  gap: var(--space-8);
  flex: 1;
}
widget-genoma-102020 .genoma-topbar-group {
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary-color);
}
widget-genoma-102020 .genoma-topbar-sep {
  color: var(--grey-color-darker);
  font-size: var(--font-size-12);
}
widget-genoma-102020 .genoma-topbar-widget {
  font-size: var(--font-size-16);
  color: var(--text-secondary-color);
  font-weight: var(--font-weight-normal);
}
widget-genoma-102020 .genoma-topbar-counter {
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
  white-space: nowrap;
}
widget-genoma-102020 .genoma-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-16);
  padding: var(--space-64);
  color: var(--text-primary-color-lighter);
  font-size: var(--font-size-16);
}
widget-genoma-102020 .genoma-spinner {
  width: 32px;
  height: 32px;
  border: 3px solid var(--grey-color);
  border-top-color: var(--text-secondary-color);
  border-radius: 50%;
  animation: genoma-spin 0.8s linear infinite;
}
@keyframes genoma-spin {
  to {
    transform: rotate(360deg);
  }
}
widget-genoma-102020 .genoma-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-16);
  padding: var(--space-64);
  color: var(--text-primary-color-lighter);
  font-size: var(--font-size-16);
}
widget-genoma-102020 .genoma-empty p {
  margin: 0;
}
widget-genoma-102020 .genoma-back-link {
  background: none;
  border: none;
  color: var(--text-secondary-color);
  font-size: var(--font-size-12);
  font-family: var(--font-family-primary);
  cursor: pointer;
  padding: 0;
}
widget-genoma-102020 .genoma-back-link:hover {
  text-decoration: underline;
}
widget-genoma-102020 .genoma-knob-layout {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: var(--space-24);
  padding: var(--space-24);
  max-width: 800px;
  margin: 0 auto;
  width: 100%;
}
widget-genoma-102020 .genoma-knob-control {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-24);
}
widget-genoma-102020 .genoma-knob-arrow {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border: 1px solid var(--grey-color);
  border-radius: 50%;
  background: var(--bg-primary-color);
  color: var(--text-primary-color-lighter);
  cursor: pointer;
  transition: all var(--transition-slow) ease;
  outline: none;
}
widget-genoma-102020 .genoma-knob-arrow:hover:not(:disabled) {
  background: var(--bg-secondary-color-lighter);
  border-color: var(--grey-color-dark);
  color: var(--text-primary-color);
}
widget-genoma-102020 .genoma-knob-arrow:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
widget-genoma-102020 .genoma-knob-arrow svg {
  display: block;
}
widget-genoma-102020 .genoma-knob-widget {
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 120px;
}
widget-genoma-102020 .genoma-widget-info {
  text-align: center;
}
widget-genoma-102020 .genoma-widget-tag {
  font-family: 'SF Mono', 'Fira Code', 'Consolas', monospace;
  font-size: var(--font-size-12);
  color: var(--text-secondary-color);
  background: rgba(28, 145, 205, 0.08);
  display: inline-block;
  padding: 4px 12px;
  border-radius: 6px;
  margin-bottom: 6px;
}
widget-genoma-102020 .genoma-widget-desc {
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
}
widget-genoma-102020 .genoma-demo-area {
  border: 1px solid var(--grey-color);
  border-radius: 10px;
  background: var(--bg-primary-color);
  overflow: hidden;
}
widget-genoma-102020 .genoma-demo-label {
  padding: var(--space-8) var(--space-16);
  font-size: 10px;
  font-weight: var(--font-weight-bold);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text-primary-color-lighter);
  background: var(--bg-secondary-color-lighter);
  border-bottom: 1px solid var(--grey-color);
}
widget-genoma-102020 .genoma-demo-container {
  padding: var(--space-24);
  min-height: 280px;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}
widget-genoma-102020 .genoma-widget-list {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-8);
  justify-content: center;
}
widget-genoma-102020 .genoma-widget-pill {
  display: inline-flex;
  align-items: center;
  padding: 6px 14px;
  font-size: var(--font-size-12);
  font-family: var(--font-family-primary);
  font-weight: var(--font-weight-normal);
  color: var(--text-primary-color-lighter);
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color);
  border-radius: 20px;
  cursor: pointer;
  transition: all var(--transition-slow) ease;
  outline: none;
}
widget-genoma-102020 .genoma-widget-pill:hover {
  background: var(--bg-secondary-color-lighter);
  border-color: var(--grey-color-dark);
  color: var(--text-primary-color);
}
widget-genoma-102020 .genoma-widget-pill.active {
  background: var(--text-secondary-color);
  border-color: var(--text-secondary-color);
  color: var(--bg-primary-color);
  font-weight: var(--font-weight-bold);
}
`);
        this.currentView = 'grid';
        this.selectedGroup = null;
        this.knobIndex = 0;
        this.filterCategory = '';
        // Map: group name → tag strings[]
        this.groupWidgetTags = new Map();
        // Track which widget tags have already been imported
        this.importedTags = new Set();
        // =========================================================================
        // CATEGORY METADATA
        // =========================================================================
        this.categoryMeta = {
            dataEntry: { label: 'Data Entry', color: 'sky' },
            dataDiscovery: { label: 'Data Discovery', color: 'amber' },
            dataDisplay: { label: 'Data Display', color: 'emerald' },
            actions: { label: 'Actions', color: 'rose' },
            navigation: { label: 'Navigation', color: 'violet' },
            feedback: { label: 'Feedback', color: 'orange' },
            identity: { label: 'Identity', color: 'teal' },
        };
    }
    // =========================================================================
    // LIFECYCLE
    // =========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.buildGroupWidgetTags();
    }
    // =========================================================================
    // BUILD GROUP → TAGS MAP
    // =========================================================================
    buildGroupWidgetTags() {
        const files = Object.values(mls.stor.files);
        const htmlFiles = files.filter((file) => file.extension === '.html' && file.folder.startsWith('molecules') && file.shortName !== 'index');
        // Group files by folder (without 'molecules/' prefix, lowercased)
        const folderMap = new Map();
        for (const file of htmlFiles) {
            const folderKey = file.folder.replace(/^molecules\//, '').toLowerCase();
            if (!folderMap.has(folderKey)) {
                folderMap.set(folderKey, []);
            }
            folderMap.get(folderKey).push(file);
        }
        // Match each mutation group to its files
        for (const group of mutationGroups) {
            const groupKey = group.name.toLowerCase();
            const matchedFiles = folderMap.get(groupKey) || [];
            const tags = matchedFiles.map((file) => convertFileToTag(file));
            this.groupWidgetTags.set(group.name, tags);
        }
    }
    // =========================================================================
    // NAVIGATION
    // =========================================================================
    async handleGroupSelect(group) {
        const tags = this.groupWidgetTags.get(group.name) || [];
        this.selectedGroup = group;
        this.knobIndex = 0;
        this.currentView = 'knob';
        // Import and render first widget
        if (tags.length > 0) {
            await this.importAndRenderWidget(0);
        }
    }
    handleBackToGrid() {
        this.currentView = 'grid';
        this.selectedGroup = null;
        this.knobIndex = 0;
        this.importedTags.clear();
    }
    // =========================================================================
    // WIDGET IMPORT + RENDER
    // =========================================================================
    async importAndRenderWidget(index) {
        if (!this.selectedGroup)
            return;
        const tags = this.groupWidgetTags.get(this.selectedGroup.name) || [];
        const tag = tags[index];
        if (!tag)
            return;
        // Import molecule if not already registered
        if (!this.importedTags.has(tag)) {
            try {
                const info = resolveTagToFile(tag);
                if (!info)
                    throw new Error('Invalid import');
                await import(`/_${info.project}_/l2/${info.folder ? info.folder + '/' : ''}${info.shortName}.js`);
                this.importedTags.add(tag);
            }
            catch (e) {
                console.error('Failed to import molecule:', tag, e);
            }
        }
        // Inject demo HTML into container
        this.updateDemoContainer();
    }
    updateDemoContainer() {
        if (!this.selectedGroup)
            return;
        const tags = this.groupWidgetTags.get(this.selectedGroup.name) || [];
        const tag = tags[this.knobIndex];
        if (!tag)
            return;
        const demo = this.selectedGroup.demo;
        const demoHtml = demo.replace(/molecule-for-replace/g, tag);
        const container = this.querySelector('#mutation-demo-container');
        if (container) {
            container.innerHTML = demoHtml;
        }
    }
    // =========================================================================
    // KNOB HANDLERS
    // =========================================================================
    async handleKnobChange(e) {
        if (!this.selectedGroup)
            return;
        const tags = this.groupWidgetTags.get(this.selectedGroup.name) || [];
        const newIndex = e.detail.value;
        if (newIndex === null || newIndex < 0 || newIndex >= tags.length)
            return;
        this.knobIndex = newIndex;
        await this.importAndRenderWidget(this.knobIndex);
    }
    async handlePillClick(index) {
        this.knobIndex = index;
        await this.importAndRenderWidget(index);
    }
    // =========================================================================
    // FILTER
    // =========================================================================
    handleFilterChange(category) {
        this.filterCategory = category;
    }
    getFilteredGroups() {
        if (!this.filterCategory)
            return mutationGroups;
        return mutationGroups.filter(g => g.category === this.filterCategory);
    }
    getActiveCategories() {
        const cats = new Set(mutationGroups.map(g => g.category));
        return Array.from(cats);
    }
    // =========================================================================
    // RENDER — MAIN
    // =========================================================================
    render() {
        return html `
            <div class="genoma-root">
                ${this.currentView === 'grid'
            ? this.renderGridView()
            : this.renderKnobView()}
            </div>
        `;
    }
    // =========================================================================
    // RENDER — GRID VIEW
    // =========================================================================
    renderGridView() {
        const groups = this.getFilteredGroups();
        const activeCategories = this.getActiveCategories();
        return html `
            <div class="genoma-grid-view">

                <div class="genoma-header">
                    <h1 class="genoma-title">Molecule Mutations</h1>
                    <p class="genoma-subtitle">Select a skill group to explore widget variations</p>
                </div>

                <div class="genoma-filters">
                    <button
                        class="genoma-filter-chip ${this.filterCategory === '' ? 'active' : ''}"
                        @click=${() => this.handleFilterChange('')}>
                        All
                    </button>
                    ${activeCategories.map(cat => html `
                        <button
                            class="genoma-filter-chip ${this.filterCategory === cat ? 'active' : ''}"
                            @click=${() => this.handleFilterChange(cat)}>
                            ${this.categoryMeta[cat].label}
                        </button>
                    `)}
                </div>

                <div class="genoma-card-grid">
                    ${groups.map(group => this.renderGroupCard(group))}
                </div>
            </div>
        `;
    }
    renderGroupCard(group) {
        const meta = this.categoryMeta[group.category];
        const iconSvg = renderIcon(group.icon, 28);
        const tags = this.groupWidgetTags.get(group.name) || [];
        return html `
            <div class="genoma-card" @click=${() => this.handleGroupSelect(group)}>
                <div class="genoma-card-icon">
                    ${unsafeHTML(iconSvg)}
                </div>
                <div class="genoma-card-body">
                    <div class="genoma-card-label">${group.label}</div>
                    <div class="genoma-card-desc">${group.shortDescription}</div>
                </div>
                <div class="genoma-card-footer">
                    <span class="genoma-card-badge">${meta.label}</span>
                    ${tags.length > 0 ? html `
                        <span class="genoma-card-count">${tags.length}</span>
                    ` : nothing}
                </div>
            </div>
        `;
    }
    // =========================================================================
    // RENDER — KNOB VIEW
    // =========================================================================
    renderKnobView() {
        if (!this.selectedGroup)
            return html `${nothing}`;
        const tags = this.groupWidgetTags.get(this.selectedGroup.name) || [];
        const total = tags.length;
        const currentTag = tags[this.knobIndex];
        return html `
            <div class="genoma-knob-view">

                <div class="genoma-topbar">
                    <button class="genoma-back-btn" @click=${this.handleBackToGrid}>
                        ${unsafeHTML(renderIcon('<path d="M19 12H5M12 19l-7-7 7-7"/>', 18))}
                        Back
                    </button>
                    <div class="genoma-topbar-title">
                        <span class="genoma-topbar-group">${this.selectedGroup.label}</span>
                        ${currentTag ? html `
                            <span class="genoma-topbar-sep">→</span>
                            <span class="genoma-topbar-widget">${currentTag}</span>
                        ` : nothing}
                    </div>
                    <div class="genoma-topbar-counter">
                        ${total > 0 ? html `${this.knobIndex + 1} / ${total}` : nothing}
                    </div>
                </div>

                ${total === 0 ? html `
                    <div class="genoma-empty">
                        <p>No widgets found for this group.</p>
                        <button class="genoma-back-link" @click=${this.handleBackToGrid}>
                            ← Back to groups
                        </button>
                    </div>
                ` : html `
                    <div class="genoma-knob-layout">

                        <div class="genoma-knob-control">
                            <collab-select-knob-102027
                                .min=${0}
                                .max=${total - 1}
                                .value=${this.knobIndex}
                                .step=${1}
                                selected
                                @knob-change=${this.handleKnobChange}>
                            </collab-select-knob-102027>
                        </div>

                        ${currentTag ? html `
                            <div class="genoma-widget-info">
                                <div class="genoma-widget-tag">&lt;${currentTag}&gt;</div>
                            </div>
                        ` : nothing}

                        <div class="genoma-demo-area">
                            <div class="genoma-demo-label">Preview</div>
                            <div id="mutation-demo-container" class="genoma-demo-container">
                            </div>
                        </div>

                        <div class="genoma-widget-list">
                            ${tags.map((tag, i) => html `
                                <button
                                    class="genoma-widget-pill ${i === this.knobIndex ? 'active' : ''}"
                                    @click=${() => this.handlePillClick(i)}>
                                    ${tag}
                                </button>
                            `)}
                        </div>

                    </div>
                `}
            </div>
        `;
    }
};
__decorate([
    state()
], WidgetGenoma102020.prototype, "currentView", void 0);
__decorate([
    state()
], WidgetGenoma102020.prototype, "selectedGroup", void 0);
__decorate([
    state()
], WidgetGenoma102020.prototype, "knobIndex", void 0);
__decorate([
    state()
], WidgetGenoma102020.prototype, "filterCategory", void 0);
WidgetGenoma102020 = __decorate([
    customElement('widget-genoma-102020')
], WidgetGenoma102020);
export { WidgetGenoma102020 };
