/// <mls fileReference="_102020_/l2/auraOrganismBase.ts" enhancement="_100554_enhancementLit" />

import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';

@customElement('aura-organism-base-102020')
export class AuraOrganismBase extends CollabLitElement {


}
