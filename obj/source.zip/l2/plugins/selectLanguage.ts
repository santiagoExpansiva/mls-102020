/// <mls fileReference="_102020_/l2/plugins/selectLanguage.ts" enhancement="_102027_/l2/enhancementLit.ts"/>

import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { getConfigProject, updateConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { languages as allLanguages, ICollabLanguage } from '/_102027_/l2/collabLanguages.js';

// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Language',
    desc: 'The language defines the locale used for i18n content generation. Each language produces translated variations of the project pages.',
    needsProject: 'Select a project first to see the available languages.',
    allTitle: 'All Languages',
    allDesc: 'Languages configured for this project.',
    customTitle: 'Add Language',
    customDesc: 'Add a new language to this project.',
    noLanguages: 'No languages configured for this project.',
    noResults: 'No languages match your search.',
    searchPlaceholder: 'Search languages…',
    add: 'Add',
    loading: 'Loading languages…',
    createNew: 'Add Language',
    removeTitle: 'Remove Language',
    removeDesc: 'This language will be permanently removed from the selected project.',
    removeBtn: 'Remove',
};
type MessageType = typeof message_en;
const messages: Record<string, MessageType> = {
    en: message_en,
    pt: {
        title: 'Idioma',
        desc: 'O idioma define o locale usado para geração de conteúdo i18n. Cada idioma produz variações traduzidas das páginas do projeto.',
        needsProject: 'Selecione um projeto primeiro para ver os idiomas disponíveis.',
        allTitle: 'Todos os Idiomas',
        allDesc: 'Idiomas configurados neste projeto.',
        customTitle: 'Adicionar Idioma',
        customDesc: 'Adicione um novo idioma a este projeto.',
        noLanguages: 'Nenhum idioma configurado neste projeto.',
        noResults: 'Nenhum idioma corresponde à sua busca.',
        searchPlaceholder: 'Buscar idiomas…',
        add: 'Adicionar',
        loading: 'Carregando idiomas…',
        createNew: 'Adicionar Idioma',
        removeTitle: 'Remover Idioma',
        removeDesc: 'Este idioma será removido permanentemente do projeto selecionado.',
        removeBtn: 'Remover',
    },
    es: {
        title: 'Idioma',
        desc: 'El idioma define el locale para la generación de contenido i18n. Cada idioma produce variaciones traducidas de las páginas del proyecto.',
        needsProject: 'Seleccione un proyecto primero para ver los idiomas disponibles.',
        allTitle: 'Todos los Idiomas',
        allDesc: 'Idiomas configurados en este proyecto.',
        customTitle: 'Agregar Idioma',
        customDesc: 'Agregue un nuevo idioma a este proyecto.',
        noLanguages: 'No hay idiomas configurados en este proyecto.',
        noResults: 'Ningún idioma coincide con su búsqueda.',
        searchPlaceholder: 'Buscar idiomas…',
        add: 'Agregar',
        loading: 'Cargando idiomas…',
        createNew: 'Agregar Idioma',
        removeTitle: 'Eliminar Idioma',
        removeDesc: 'Este idioma será eliminado permanentemente del proyecto seleccionado.',
        removeBtn: 'Eliminar',
    },
};
/// **collab_i18n_end**

// ─── Types ───────────────────────────────────────────────────────────

interface IProject {
    project: number;
    name: string;
    doSelect: boolean;
}

// ─── Component ───────────────────────────────────────────────────────

@customElement('plugins--select-language-102020')
export class PluginSelectLanguage extends StateLitElement {

    @property({ attribute: false }) selectedProject: IProject | null = null;
    @property({ attribute: false }) value: number | null = null;

    @state() private _languages: string[] = [];
    @state() private _loading: boolean = false;
    @state() private _search: string = '';
    @state() private _addSearch: string = '';
    @state() private _addSelected: string = '';
    @state() private _adding: boolean = false;
    @state() private _dropdownOpen: boolean = false;
    @state() private _removing: boolean = false;
    @state() config: mls.l5_common.ProjectConfig | undefined;

    willUpdate(changed: Map<string, unknown>) {
        if (changed.has('selectedProject')) {
            this._languages = [];
            this._search = '';
            this._addSearch = '';
            this._addSelected = '';
            if (this.selectedProject) this._loadLanguages(this.selectedProject.project);
        }
        if (changed.has('value')) {
            this._search = '';
            this._addSearch = '';
            this._addSelected = '';
            this._dropdownOpen = false;
        }
    }

    private get msg(): MessageType {
        return messages[this.getMessageKey(messages)];
    }

    private get _isAll(): boolean { return this.value === 0; }

    private get _isCustom(): boolean {
        return this.value !== null && this.value > this._languages.length;
    }

    private get _selectedLang(): string | null {
        if (this.value === null || this.value <= 0 || this.value > this._languages.length) return null;
        return this._languages[this.value - 1];
    }

    createRenderRoot() { return this; }

    render() {
        if (!this.selectedProject) return this._renderNeedsProject();
        if (this._loading) return this._renderLoading();
        if (this._isAll) return this._renderAll();
        if (this._isCustom) return this._renderCustom();
        return this._renderSelected();
    }

    // ─── Async ───────────────────────────────────────────────────────

    private async _loadLanguages(projectId: number) {
        this._loading = true;
        this.requestUpdate();
        try {
            this.config = await getConfigProject(projectId);
            this._languages = (this.config as any)?.languages?.map((i: any) => i.language) ?? [];
        } catch {
            this._languages = [];
        }
        this._loading = false;
        this._dispatchConfig();
        this.requestUpdate();
    }

    private async _addLanguage() {
        if (!this._addSelected || !this.selectedProject || !this.config) return;
        this._adding = true;
        this.requestUpdate();
        try {
            const existing: any[] = (this.config as any).languages ?? [];
            const updated = { ...(this.config as any), languages: [...existing, { language: this._addSelected }] };
            await updateConfigProject(this.selectedProject.project, updated);
            this.config = updated as any;
            this._languages = updated.languages.map((i: any) => i.language);
            this._dispatchConfig();
            const newIndex = this._languages.indexOf(this._addSelected);
            if (newIndex >= 0) this._dispatchSelect(newIndex + 1);
        } catch {}
        this._adding = false;
        this.requestUpdate();
    }

    private async _removeLanguage() {
        const lang = this._selectedLang;
        if (!lang || !this.selectedProject || !this.config) return;
        this._removing = true;
        this.requestUpdate();
        try {
            const existing: any[] = (this.config as any).languages ?? [];
            const updated = { ...(this.config as any), languages: existing.filter((i: any) => i.language !== lang) };
            await updateConfigProject(this.selectedProject.project, updated);
            this.config = updated as any;
            this._languages = updated.languages.map((i: any) => i.language);
            this._dispatchConfig();
            this._dispatchSelect(0);
        } catch {}
        this._removing = false;
        this.requestUpdate();
    }

    // ─── Scenario renders ─────────────────────────────────────────────

    private _renderNeedsProject() {
        return html`
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.title, this.msg.desc)}
                ${this._renderNotice(this.msg.needsProject)}
            </div>
        `;
    }

    private _renderLoading() {
        return html`
            <div class="flex flex-col gap-3">
                ${this._renderHeader(this.msg.title, this.msg.desc)}
                <span class="text-xs text-gray-400 dark:text-gray-600 italic">${this.msg.loading}</span>
            </div>
        `;
    }

    private _renderSelected() {
        const lang = this._selectedLang!;
        const langObj = (allLanguages as any[]).find(l => l.code === lang);
        const fullName = langObj?.name ?? lang;
        const svg = langObj?.svg ?? '';
        const max = this._languages.length + 1;
        return html`
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.title, this.msg.desc, this.value ?? 0, 0, max)}
                <div class="
                    rounded-lg border border-gray-200 dark:border-gray-800
                    bg-gray-50 dark:bg-gray-900/50
                    px-3 py-2.5 flex items-center gap-2
                ">
                    <div class="shrink-0 w-[30px] h-7 overflow-hidden rounded-sm">${unsafeHTML(svg)}</div>
                    <span class="text-xs text-gray-700 dark:text-gray-300">${fullName}</span>
                    <span class="
                        ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded
                        bg-emerald-100 dark:bg-emerald-900/30
                        text-emerald-600 dark:text-emerald-400
                        font-semibold uppercase tracking-wider
                    ">${lang}</span>
                </div>
                <fieldset class="rounded-lg border border-red-200 dark:border-red-800/40 px-3 py-2.5 flex flex-col gap-2">
                    <legend class="text-[10px] font-medium text-red-500 dark:text-red-400 px-1">${this.msg.removeTitle}</legend>
                    <span class="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">${this.msg.removeDesc}</span>
                    <button
                        class="
                            self-start text-xs px-3 py-1.5 rounded transition-colors
                            ${this._removing
                                ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 dark:text-gray-600 cursor-not-allowed'
                                : 'bg-red-500 dark:bg-red-600 text-white hover:bg-red-600 dark:hover:bg-red-500 cursor-pointer'}
                        "
                        ?disabled=${this._removing}
                        @click=${() => this._removeLanguage()}
                    >${this.msg.removeBtn}</button>
                </fieldset>
            </div>
        `;
    }

    private _renderAll() {
        const q = this._search.toLowerCase();
        const filtered = this._languages
            .map((lang, i) => ({ lang, selectValue: i + 1 }))
            .filter(({ lang }) => {
                if (!q) return true;
                const name = (allLanguages as ICollabLanguage[]).find(l => l.code === lang)?.name ?? '';
                return lang.toLowerCase().includes(q) || name.toLowerCase().includes(q);
            });

        const max = this._languages.length + 1;
        return html`
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.allTitle, this.msg.allDesc, 0, 0, max)}
                <button
                    class="
                        self-end text-[10px] px-2.5 py-1 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors whitespace-nowrap
                    "
                    @click=${() => this._dispatchSelect(max)}
                >+ ${this.msg.createNew}</button>

                <input
                    type="text"
                    .value=${this._search}
                    placeholder=${this.msg.searchPlaceholder}
                    class="
                        w-full text-xs px-2.5 py-1.5 rounded-md
                        border border-gray-200 dark:border-gray-700
                        bg-white dark:bg-gray-900
                        text-gray-700 dark:text-gray-300
                        placeholder-gray-400 dark:placeholder-gray-600
                        focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                    "
                    @input=${(e: Event) => { this._search = (e.target as HTMLInputElement).value; }}
                />

                ${this._languages.length === 0
                    ? html`<span class="text-[11px] text-gray-400 dark:text-gray-600 italic">${this.msg.noLanguages}</span>`
                    : filtered.length === 0
                        ? html`<span class="text-[11px] text-gray-400 dark:text-gray-600 italic">${this.msg.noResults}</span>`
                        : html`
                            <div class="flex flex-col gap-1.5">
                                ${filtered.map(({ lang, selectValue }) => this._renderLangCard(lang, selectValue))}
                            </div>
                        `}
            </div>
        `;
    }

    private _renderCustom() {
        const q = this._addSearch.toLowerCase();
        const alreadyAdded = new Set(this._languages);
        const selectedObj = this._addSelected
            ? (allLanguages as ICollabLanguage[]).find(l => l.code === this._addSelected) ?? null
            : null;
        const filtered = (allLanguages as ICollabLanguage[]).filter(l =>
            !alreadyAdded.has(l.code) &&
            (!q || l.name.toLowerCase().includes(q) || l.code.toLowerCase().includes(q))
        ).slice(0, 80);

        const max = this._languages.length + 1;
        return html`
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.customTitle, this.msg.customDesc, max, 0, max)}

                <input
                    type="text"
                    .value=${this._addSearch}
                    placeholder=${this.msg.searchPlaceholder}
                    class="
                        w-full text-xs px-2.5 py-1.5 rounded-md
                        border border-gray-200 dark:border-gray-700
                        bg-white dark:bg-gray-900
                        text-gray-700 dark:text-gray-300
                        placeholder-gray-400 dark:placeholder-gray-600
                        focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                    "
                    @focus=${() => { this._dropdownOpen = true; }}
                    @blur=${() => { setTimeout(() => { this._dropdownOpen = false; this.requestUpdate(); }, 150); }}
                    @input=${(e: Event) => { this._addSearch = (e.target as HTMLInputElement).value; this._addSelected = ''; this._dropdownOpen = true; }}
                />

                ${this._dropdownOpen ? html`
                    <div class="flex flex-col gap-0.5 max-h-52 overflow-y-auto border border-gray-200 dark:border-gray-700 rounded-md bg-white dark:bg-gray-900 py-0.5">
                        ${filtered.length === 0
                            ? html`<span class="px-3 py-2 text-[11px] text-gray-400 dark:text-gray-600 italic">${this.msg.noResults}</span>`
                            : filtered.map(l => html`
                                <div
                                    class="
                                        flex items-center gap-2 px-3 py-1.5 cursor-pointer
                                        hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors
                                    "
                                    @mousedown=${(e: Event) => { e.preventDefault(); this._addSelected = l.code; this._addSearch = l.name; this._dropdownOpen = false; }}
                                >
                                    <div class="shrink-0 w-[30px] h-7 overflow-hidden rounded-sm">${unsafeHTML((l as any).svg ?? '')}</div>
                                    <span class="text-xs text-gray-700 dark:text-gray-300">${l.name}</span>
                                    <span class="
                                        ml-auto shrink-0 text-[10px] font-mono px-1.5 py-0.5 rounded
                                        bg-gray-100 dark:bg-gray-800
                                        text-gray-500 dark:text-gray-400
                                        uppercase tracking-wider
                                    ">${l.code}</span>
                                </div>
                            `)}
                    </div>
                ` : ''}

                ${selectedObj ? html`
                    <div class="
                        flex items-center gap-2 px-2.5 py-2 rounded-md
                        border border-indigo-200 dark:border-indigo-700
                        bg-indigo-50 dark:bg-indigo-900/10
                    ">
                        <div class="shrink-0 w-[30px] h-7 overflow-hidden rounded-sm">${unsafeHTML((selectedObj as any).svg ?? '')}</div>
                        <span class="flex-1 text-xs text-gray-700 dark:text-gray-300">${selectedObj.name}</span>
                        <span class="
                            shrink-0 text-[10px] font-mono px-1.5 py-0.5 rounded
                            bg-indigo-100 dark:bg-indigo-900/30
                            text-indigo-600 dark:text-indigo-400
                            uppercase tracking-wider
                        ">${selectedObj.code}</span>
                        <button
                            class="shrink-0 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-colors leading-none"
                            @click=${() => { this._addSelected = ''; this._addSearch = ''; }}
                        >&#x2715;</button>
                    </div>
                ` : ''}

                <button
                    class="
                        self-start text-xs px-3 py-1.5 rounded
                        transition-colors
                        ${!this._addSelected || this._adding
                            ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 dark:text-gray-600 cursor-not-allowed'
                            : 'bg-indigo-500 dark:bg-indigo-600 text-white hover:bg-indigo-600 dark:hover:bg-indigo-500 cursor-pointer'}
                    "
                    ?disabled=${!this._addSelected || this._adding}
                    @click=${() => this._addLanguage()}
                >${this.msg.add}</button>
            </div>
        `;
    }

    // ─── Shared helpers ───────────────────────────────────────────────

    private _renderHeader(title: string, description: string) {
        return html`
            <div class="flex flex-col gap-1">
                <span class="text-lg font-semibold text-gray-700 dark:text-gray-200">${title}</span>
                <span class="text-xs text-gray-400 dark:text-gray-500 leading-relaxed">${description}</span>
            </div>
        `;
    }

    private _renderNotice(message: string) {
        return html`
            <div class="
                rounded-lg border border-amber-200 dark:border-amber-800/40
                bg-amber-50 dark:bg-amber-900/10
                px-3 py-2.5
            ">
                <span class="text-[11px] text-amber-600 dark:text-amber-400 leading-relaxed">${message}</span>
            </div>
        `;
    }

    private _renderLangCard(lang: string, selectValue: number) {
        const langObj = (allLanguages as any[]).find(l => l.code === lang);
        const fullName = langObj?.name ?? lang;
        const svg = langObj?.svg ?? '';
        return html`
            <div
                class="
                    rounded-lg border border-gray-200 dark:border-gray-800
                    bg-gray-50 dark:bg-gray-900/50
                    px-3 py-2.5 flex items-center gap-2
                    cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/70 transition-colors
                "
                @click=${() => this._dispatchSelect(selectValue)}
            >
                <div class="shrink-0 w-[30px] h-7 overflow-hidden rounded-sm">${unsafeHTML(svg)}</div>
                <span class="text-xs text-gray-700 dark:text-gray-300">${fullName}</span>
                <span class="
                    ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded
                    bg-emerald-100 dark:bg-emerald-900/30
                    text-emerald-600 dark:text-emerald-400
                    font-semibold uppercase tracking-wider
                ">${lang}</span>
            </div>
        `;
    }

    private _renderNavHeader(title: string, desc: string, value: number, min: number, max: number) {
        const atMin = value <= min;
        const atMax = value >= max;
        const navBtn = (label: string, target: number, disabled: boolean) => html`
            <button
                class="px-1.5 py-1 rounded text-base font-mono leading-none transition-colors
                    ${disabled
                        ? 'text-gray-300 dark:text-gray-700 cursor-default'
                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer'}"
                ?disabled=${disabled}
                @click=${() => { if (!disabled) this._dispatchSelect(target); }}
            >${label}</button>
        `;
        return html`
            <div class="flex flex-col gap-1">
                <div class="flex items-center">
                    <div class="flex items-center gap-0.5">
                        ${navBtn('‹', value - 1, atMin)}
                        ${navBtn('«', min, atMin)}
                    </div>
                    <span class="flex-1 text-center text-lg font-semibold text-gray-700 dark:text-gray-200">${title}</span>
                    <div class="flex items-center gap-0.5">
                        ${navBtn('›', value + 1, atMax)}
                        ${navBtn('»', max, atMax)}
                    </div>
                </div>
                <span class="text-xs text-gray-400 dark:text-gray-500 leading-relaxed">${desc}</span>
            </div>
        `;
    }

    private _dispatchConfig() {
        const labels: Record<number, string> = { 0: 'All' };
        this._languages.forEach((lang, i) => { labels[i + 1] = lang; });
        labels[this._languages.length + 1] = '+';
        this.dispatchEvent(new CustomEvent('lang-config', {
            detail: { min: 0, max: this._languages.length + 1, labels },
            bubbles: true,
            composed: true,
        }));
    }

    private _dispatchSelect(value: number) {
        this.dispatchEvent(new CustomEvent('select-language', {
            detail: { value },
            bubbles: true,
            composed: true,
        }));
    }
}
