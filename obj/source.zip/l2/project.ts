/// <mls fileReference="_102020_/l2/project.ts" groupName="other" enhancement="_blank" />

export const projectConfig = {
  "modules": [],
}